﻿using System;
using System.Collections.Generic;
using Microsoft.Kinect;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GettingColorStream
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region Kinect Objects
        KinectSensor sensor;

        #endregion

        public MainWindow()
        {
            InitializeComponent();
            sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
            if (sensor.ColorStream.IsEnabled == false)
            {
                sensor.ColorStream.Enable();
                sensor.ColorFrameReady += new EventHandler<ColorImageFrameReadyEventArgs>(sensor_ColorFrameReady);
            }
            sensor.Start();
        }

        void sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
            {

                if (colorImageFrame == null)
                {
                    return;
                }
                var pixelData = new byte[colorImageFrame.PixelDataLength];
                colorImageFrame.CopyPixelDataTo(pixelData);

                int stride = colorImageFrame.Width * colorImageFrame.BytesPerPixel;

                colorImageControl.Source = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height,
                    96,96,PixelFormats.Bgr32, null,pixelData,stride);
            }
        }
    }
}
