﻿//The application is not completed.It will require more precise skeleton smoothing paramters.
//Next it will require 
using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Microsoft.Kinect;
using Coding4Fun.Kinect.Wpf;
using Microsoft.Kinect.Toolkit;
using Microsoft.Kinect.Toolkit.Controls;

namespace PlayMusicWithKinect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    #region GestureSounds and Instruments
    enum GestureSounds
    {
        gestureSound1,
        gestureSound2,
        gestureSound3,
        gestureSound4,
        gestureSound5,
        gestureSound6,
        gestureSound7,
        gestureSound8,

        footSound1,
        footSound2,
        footSound3,
        footSound4,
        footSound5,
        footSound6,
        footSound7,
        footSound8,

        headSound
    }

    enum Instrument
    {
        Drum,
        Piano,
        TribleDisc
    }

    #endregion

     

    public partial class MainWindow : Window
    {
        #region BitResetCollection
        private bool KeyPressed_1;
        private bool KeyPressed_2;
        private bool KeyPressed_3;
        private bool KeyPressed_4;
        private bool KeyPressed_5;
        private bool KeyPressed_6;
        private bool KeyPressed_7;
        private bool KeyPressed_8;
        #endregion

        #region KinectObjects
        private readonly KinectSensorChooser sensorChooser;
        //private  KinectSensor sensor;

        //Can be used with previous Implementation
        //string MediaFile;

        public Brush BoneColor { get; set; }
        private Instrument SelectedInstrument { get; set; }


        private Skeleton[] totalSkeletons = new Skeleton[6];
        float skeletonMaxX = 1.0f;
        float skeletonMaxY = 1.0f;
        int elementCounter;
        int maxScreenHeight = 0;
        int maxScreenWidth = 0;
        bool Gesture1_IsPerformed;
        bool Gesture2_IsPerformed;
        bool Gesture3_IsPerformed;
        bool Gesture4_IsPerformed;
        bool Gesture5_IsPerformed;
        bool Gesture6_IsPerformed;
        bool Gesture7_IsPerformed;
        bool Gesture8_IsPerformed;
        
        #endregion

        public MainWindow()
        {
            InitializeComponent();

            #region Boiler Plate for Kinect Interactions.
            this.sensorChooser = new KinectSensorChooser();
            this.sensorChooser.KinectChanged += SensorChooserOnKinectChanged;
            this.sensorChooserUi.KinectSensorChooser = this.sensorChooser;
            this.sensorChooser.Start();
            var regionSensorBinding = new Binding("Kinect") { Source = this.sensorChooser };
            BindingOperations.SetBinding(this.ActionRegion, KinectRegion.KinectSensorProperty, regionSensorBinding);
            #endregion

            //Used for counting the UI controls in the form.
            elementCounter = KinectCanvas.Children.Count;

            //Intializing the selected Instrument
            SelectedInstrument = Instrument.Drum;
            //StatusBarUpdator();
            
        }

        #region TheUltimateEvent
        private void SensorChooserOnKinectChanged(object sender, KinectChangedEventArgs args)
        {
            if (args.OldSensor != null)
            {
                try
                {
                    args.OldSensor.DepthStream.Range = DepthRange.Default;
                    args.OldSensor.SkeletonStream.EnableTrackingInNearRange = false;
                    args.OldSensor.DepthStream.Disable();
                    args.OldSensor.SkeletonStream.Disable();
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }

            if (args.NewSensor != null)
            {
                try
                {
                    args.NewSensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);

                    if (args.NewSensor.SkeletonStream.IsEnabled == false)
                    {
                        args.NewSensor.SkeletonStream.Enable(new TransformSmoothParameters() { Correction = 0.5f, JitterRadius = 0.5f, Prediction = 0.5f, Smoothing = 0.9f });
                        args.NewSensor.SkeletonFrameReady += NewSensor_SkeletonFrameReady;
                    }

                    if (args.NewSensor.ColorStream.IsEnabled == false)
                    {
                        args.NewSensor.ColorStream.Enable();
                        args.NewSensor.ColorFrameReady += NewSensor_ColorFrameReady;
                    }

                    //maxScreenHeight = Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenHeight);
                    //maxScreenWidth = Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenWidth);

                    maxScreenHeight = Convert.ToInt32(this.KinectCanvas.Height);
                    maxScreenWidth = Convert.ToInt32(this.KinectCanvas.Width);


                    args.NewSensor.ElevationAngle = 0;

                    try
                    {
                        args.NewSensor.DepthStream.Range = DepthRange.Near;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = true;
                    }
                    catch (InvalidOperationException)
                    {
                        // Non Kinect for Windows devices do not support Near mode, so reset back to default mode.
                        args.NewSensor.DepthStream.Range = DepthRange.Default;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = false;
                    }
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }
        }
        #endregion

        void NewSensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
            {
                if (colorImageFrame == null)
                {
                    return;
                }
                var pixelData = new byte[colorImageFrame.PixelDataLength];
                colorImageFrame.CopyPixelDataTo(pixelData);

                int stride = colorImageFrame.Width * colorImageFrame.BytesPerPixel;

                ColorImageControl.Source = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height,
                      96, 96, PixelFormats.Bgr32, null, pixelData, stride);
            }
        }

        void NewSensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;

                }
                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();
                if (firstSkeleton == null)
                {
                    return;
                }

                if (totalSkeletons.Count(skull => skull.TrackingState == SkeletonTrackingState.Tracked) == 1)
                {
                    try
                    {
                        //MessageBox.Show(this.sensorChooser.Kinect.CoordinateMapper.MapSkeletonPointToDepthPoint(firstSkeleton.Joints[JointType.Head].Position, DepthImageFormat.Resolution640x480Fps30).Depth.ToString());
                        if (this.sensorChooser.Kinect.CoordinateMapper.MapSkeletonPointToDepthPoint(firstSkeleton.Joints[JointType.Head].Position, DepthImageFormat.Resolution640x480Fps30).Depth > 1400)//distance in mm
                        {
                            //rigth arm 
                            KinectCanvas.Children.Add(CreateFigure(firstSkeleton, new JointType[] {  JointType.ShoulderRight, JointType.ElbowRight,
JointType.WristRight, JointType.HandRight }));

                            //left arm
                            KinectCanvas.Children.Add(CreateFigure(firstSkeleton, new JointType[] {  JointType.ShoulderLeft, JointType.ElbowLeft,
JointType.WristLeft, JointType.HandLeft }));

                            //head and middle body.
                            KinectCanvas.Children.Add(CreateFigure(firstSkeleton, new JointType[]{ JointType.Head, JointType.ShoulderCenter,
                JointType.ShoulderLeft, JointType.Spine,
                JointType.ShoulderRight, JointType.ShoulderCenter,
                JointType.HipCenter, JointType.HipLeft,
                JointType.Spine, JointType.HipRight,
                JointType.HipCenter}));

                            //left leg
                            KinectCanvas.Children.Add(CreateFigure(firstSkeleton, new JointType[]{ JointType.HipLeft, JointType.KneeLeft,
                    JointType.AnkleLeft, JointType.FootLeft}));

                            //right leg
                            KinectCanvas.Children.Add(CreateFigure(firstSkeleton, new JointType[]{ JointType.HipRight, JointType.KneeRight,
                JointType.AnkleRight, JointType.FootRight}));


                            MapJointsToUIElements(firstSkeleton);


                            //removing the bones after drawing.
                            for (int i = 1; i < 6; i++)
                            {
                                KinectCanvas.Children.RemoveAt(elementCounter - i);
                            }

                        }
                        else
                        {
                            //Maintain distance message
                        }
                    }

                    catch (Exception exp)
                    {
                        //handle the exception for getting for
                        
                    }

                }

            }
        }

        private Point JointMapper(Joint trackedJoint)
        {
            var scaledJoint = trackedJoint.ScaleTo(
                   maxScreenWidth,
                 maxScreenHeight,
                 skeletonMaxX,
                 skeletonMaxY
                 );

            return new Point() { X = scaledJoint.Position.X, Y = scaledJoint.Position.Y };
        }

        private void JointMapper(Joint jointToMap, UIElement mappedUIElement)
        {
            Joint scaledJoint = jointToMap.ScaleTo(maxScreenWidth, maxScreenHeight, skeletonMaxX, skeletonMaxY);

            //code required for mapping the head 
            //if (mappedUIElement is Image)
            //{
            //    Image mappedImage = mappedUIElement as Image;
            //    var midX = scaledJoint.Position.X - (mappedImage.ActualWidth / 2);
            //    Canvas.SetLeft(mappedUIElement, midX);
            //    Canvas.SetTop(mappedUIElement, scaledJoint.Position.Y);

            //}
            //else
            //{
            Canvas.SetLeft(mappedUIElement, scaledJoint.Position.X);
            Canvas.SetTop(mappedUIElement, scaledJoint.Position.Y);
            //}

            //Validating conditions for gestures.

        }

        private void MapJointsToUIElements(Skeleton firstSkeleton)
        {
            //MAPPING RIGHT HAND.
            JointMapper(firstSkeleton.Joints[JointType.HandRight], rightHandPointer);

            //MAPPING LEFT HAND
            JointMapper(firstSkeleton.Joints[JointType.HandLeft], leftHandPointer);

            //MAPPING  HEAD
            JointMapper(firstSkeleton.Joints[JointType.Head], headPointer);

            //MAPPING OF LEFT SHOULDER
            JointMapper(firstSkeleton.Joints[JointType.ShoulderLeft], leftShoulderPointer);

            //MAPPING OF RIGHT SHOULDER
            JointMapper(firstSkeleton.Joints[JointType.ShoulderRight], rightShoulderPointer);

            //MAPPING OF SHOULDER CENTER
            JointMapper(firstSkeleton.Joints[JointType.ShoulderCenter], shoulderCenterPointer);

            //Mapping of left elbow
            JointMapper(firstSkeleton.Joints[JointType.ElbowLeft], leftElbowPointer);

            //Mapping of right elbow
            JointMapper(firstSkeleton.Joints[JointType.ElbowRight], rightElbowPointer);

            //Mapping of left wrist
            JointMapper(firstSkeleton.Joints[JointType.WristLeft], leftWristPointer);

            //Mapping of right wrist
            JointMapper(firstSkeleton.Joints[JointType.WristRight], rightWristPointer);

            //Mapping of spine
            JointMapper(firstSkeleton.Joints[JointType.Spine], spinePointer);

            //mapping of left hip joint.
            JointMapper(firstSkeleton.Joints[JointType.HipLeft], leftHipJointPointer);

            //Mapping of center hip joint
            JointMapper(firstSkeleton.Joints[JointType.HipCenter], centerHipJointPointer);

            //Mapping of right hip joint
            JointMapper(firstSkeleton.Joints[JointType.HipRight], rightHipJointPointer);

            //mapping of left knee joint
            JointMapper(firstSkeleton.Joints[JointType.KneeLeft], leftKneePointer);

            //mapping of right knee joint
            JointMapper(firstSkeleton.Joints[JointType.KneeRight], rightKneePointer);

            //mapping of left ankle
            JointMapper(firstSkeleton.Joints[JointType.AnkleLeft], leftAnklePointer);

            //mapping of right ankle
            JointMapper(firstSkeleton.Joints[JointType.AnkleRight], rightAnklePointer);

            //mapping of left foot
            JointMapper(firstSkeleton.Joints[JointType.FootLeft], leftfootPointer);

            //mapping of right foot
            JointMapper(firstSkeleton.Joints[JointType.FootRight], rightfootPointer);

            //mapping for Head
            // JointMapper(firstSkeleton.Joints[JointType.Head], img_Head as UIElement);

            GestureValidator(firstSkeleton);
        }

        public void MediaPlayer(string fileLocation)
        {
            soundPlayer.Source = new Uri(fileLocation);
            soundPlayer.Play();
        }

        private void MusicSelector(GestureSounds sound, Instrument instrument)
        {
            if (instrument == Instrument.Drum)
            {                
                //Loading the required files form file system.
                StringBuilder sb1 = new StringBuilder(System.AppDomain.CurrentDomain.BaseDirectory);
                sb1.Replace("\\bin\\Debug\\", "\\Sounds\\Drum");

                switch (sound)
                {
                    case GestureSounds.gestureSound1:
                        MediaPlayer(sb1.Append("\\xylo_1.mp3").ToString());
                        break;

                    case GestureSounds.gestureSound2:
                       MediaPlayer(sb1.Append("\\xylo_2.mp3").ToString());
                        break;
                    case GestureSounds.gestureSound3:
                        MediaPlayer(sb1.Append("\\xylo_3.mp3").ToString());
                        
                        break;
                    case GestureSounds.gestureSound4:
                        MediaPlayer(sb1.Append("\\xylo_4.mp3").ToString());
                        
                        break;
                    case GestureSounds.gestureSound5:
                        MediaPlayer( sb1.Append("\\xylo_5.mp3").ToString());
                        
                        break;
                    case GestureSounds.gestureSound6:
                        MediaPlayer( sb1.Append("\\xylo_6.mp3").ToString());
                        
                        break;
                    case GestureSounds.gestureSound7:
                        MediaPlayer( sb1.Append("\\xylo_7.mp3").ToString());
                        
                        break;
                    case GestureSounds.gestureSound8:
                        MediaPlayer(sb1.Append("\\xylo_8.mp3").ToString());
                        
                        break;
                    default:
                        MediaPlayer(string.Empty);
                        break;
                }

            }
            else if (instrument == Instrument.Piano)
            {
                StringBuilder sb2 = new StringBuilder(System.AppDomain.CurrentDomain.BaseDirectory);
                sb2.Replace("\\bin\\Debug\\", "\\Sounds\\Drum");

                switch (sound)
                {
                    case GestureSounds.footSound1:
                        MediaPlayer(sb2.Append("\\piano_1.mp3").ToString());
                        break;

                    case GestureSounds.footSound2:
                        MediaPlayer(sb2.Append("\\piano_2.mp3").ToString());
                        break;
                    case GestureSounds.footSound3:
                        MediaPlayer(sb2.Append("\\piano_3.mp3").ToString());

                        break;
                    case GestureSounds.footSound4:
                        MediaPlayer(sb2.Append("\\piano_4.mp3").ToString());

                        break;
                    case GestureSounds.footSound5:
                        MediaPlayer(sb2.Append("\\piano_5.mp3").ToString());

                        break;
                    case GestureSounds.footSound6:
                        MediaPlayer(sb2.Append("\\piano_6.mp3").ToString());

                        break;
                    //case GestureSounds.footSound7:
                    //    MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                    //    break;
                    //case GestureSounds.footSound8:
                    //    MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());
                        //break;
                    default:
                        MediaPlayer(string.Empty);
                        break;
                }
            }
            else if (instrument == Instrument.TribleDisc)
            {
                
            }
        }

        private bool GestureValidator(Skeleton trackedSkeleton)
        {
            //Validating the Head-Right Hand interaction
            var HeadJoint = trackedSkeleton.Joints[JointType.Head];
            var RightHandJoint = trackedSkeleton.Joints[JointType.HandRight];
            var rightelbowJoint = trackedSkeleton.Joints[JointType.ElbowRight];
            var rightshoulder = trackedSkeleton.Joints[JointType.ShoulderRight];
            var spineJoint = trackedSkeleton.Joints[JointType.Spine];
            var leftHandJoint = trackedSkeleton.Joints[JointType.HandLeft];
            var leftelbowJoint = trackedSkeleton.Joints[JointType.ElbowLeft];
            var leftshoulder = trackedSkeleton.Joints[JointType.ShoulderLeft];
            var shoulderCenter = trackedSkeleton.Joints[JointType.ShoulderCenter];
            var hipCenter = trackedSkeleton.Joints[JointType.HipCenter];
            var leftKnee = trackedSkeleton.Joints[JointType.KneeLeft];
            var rightKnee = trackedSkeleton.Joints[JointType.KneeRight];
            var leftFoot = trackedSkeleton.Joints[JointType.FootLeft];
            var rightFoot = trackedSkeleton.Joints[JointType.FootRight];
            var distance_rightHand_lefthand = GetDistance(HeadJoint, leftFoot);

            //tb_1.Text = distance_rightHand_lefthand.ToString();

            #region Gesture 1 : Hand-Head Interaction

            //condition
            if (rightelbowJoint.Position.Y > rightshoulder.Position.Y)
            {
                //tb_1.Text = string.Format("Head X :{0}  Head z :{1}", Convert.ToInt32(HeadJoint.Position.X * 100), Convert.ToInt32(100 * HeadJoint.Position.Z));
                //tb_2.Text = string.Format("Hand X :{0}  Hand z :{1}", Convert.ToInt32(100 * RightHandJoint.Position.X), Convert.ToInt32(100 * RightHandJoint.Position.Z));

                var distanceBetweenHeadandRightHand = GetDistance(HeadJoint, RightHandJoint);
                if (RightHandJoint.Position.X > HeadJoint.Position.X && distanceBetweenHeadandRightHand <= 15 && Gesture1_IsPerformed == false)
                {
                    // soundplayer.Source = new Uri("sounds/file.wmv");

                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();

                    MusicSelector(GestureSounds.gestureSound1,  SelectedInstrument);

                    Gesture1_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                else if (distanceBetweenHeadandRightHand > 25)
                {
                    Gesture1_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }

            }
            #endregion

            #region Gesture 2 : Right Hand and Right Shoulder Interaction

            else if (RightHandJoint.Position.Y < HeadJoint.Position.Y && rightelbowJoint.Position.Y <= rightshoulder.Position.Y && RightHandJoint.Position.Y > spineJoint.Position.Y)
            {
                var distance_RightHand_RightShoulder = GetDistance(RightHandJoint, rightshoulder);

                if (RightHandJoint.Position.X > rightshoulder.Position.X && distance_RightHand_RightShoulder <= 10 && Gesture2_IsPerformed == false)
                {
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();

                    MusicSelector(GestureSounds.gestureSound2, SelectedInstrument);
                    Gesture2_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                else if (distance_RightHand_RightShoulder > 25)
                {
                    Gesture2_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion

            #region Gesture 3 : LeftHand and Head Interaction
            else if (leftHandJoint.Position.Y > HeadJoint.Position.Y)
            {
                var difference_Head_LeftHand = GetDistance(HeadJoint, leftHandJoint);
                if (leftHandJoint.Position.X < HeadJoint.Position.X && difference_Head_LeftHand <= 15 && Gesture3_IsPerformed == false)
                {
                    // soundplayer.Source = new Uri("sounds/file.wmv");
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();

                    MusicSelector(GestureSounds.gestureSound3, SelectedInstrument);
                  
                    Gesture3_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                else if (difference_Head_LeftHand > 25)
                {
                    Gesture3_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }

            }
            #endregion

            #region Gesture 4:left Hand and left Shoulder Interaction

            else if (leftHandJoint.Position.Y < HeadJoint.Position.Y && leftelbowJoint.Position.Y <= leftshoulder.Position.Y && leftHandJoint.Position.Y > spineJoint.Position.Y)
            {
                var distance_leftHand_leftShoulder = GetDistance(leftHandJoint, leftshoulder);

                if (leftHandJoint.Position.X < leftshoulder.Position.X && distance_leftHand_leftShoulder <= 10 && Gesture4_IsPerformed == false)
                {
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();

                    MusicSelector(GestureSounds.gestureSound4, SelectedInstrument);

                    Gesture4_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                else if (distance_leftHand_leftShoulder > 25)
                {
                    Gesture4_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion

                //rewrite the interaction
            #region Gesture 5 : rightHand and Left Elbow
            else if (RightHandJoint.Position.X < hipCenter.Position.X && RightHandJoint.Position.Y > hipCenter.Position.Y && leftHandJoint.Position.Y < RightHandJoint.Position.Y)
            {
                var distance_rightHand_leftElbow = GetDistance(leftelbowJoint, RightHandJoint);
                //tb_1.Text = distance_rightHand_leftElbow.ToString();
                if (distance_rightHand_leftElbow <= 13 && Gesture5_IsPerformed == false)
                {
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();
                    MusicSelector(GestureSounds.gestureSound5, SelectedInstrument);

                    Gesture5_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                //else if (distance_rightHand_leftElbow > 17 || distance_rightHand_lefthand > 45)
                else if (distance_rightHand_leftElbow > 20 || distance_rightHand_lefthand >= 45)
                {
                    Gesture5_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion
                //rewrite the interaction
            #region Gesture 6 : leftHand and Right Elbow
            else if (leftHandJoint.Position.X > hipCenter.Position.X && leftHandJoint.Position.Y > hipCenter.Position.Y && leftHandJoint.Position.Y > RightHandJoint.Position.Y)
            {
                var distance_leftHand_rightElbow = GetDistance(rightelbowJoint, leftHandJoint);
                //tb_1.Text = distance_rightHand_leftElbow.ToString();
                if (distance_leftHand_rightElbow <= 13 && Gesture6_IsPerformed == false)
                {
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();
                    MusicSelector(GestureSounds.gestureSound6, SelectedInstrument);

                    Gesture6_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                //else if (distance_leftHand_rightElbow > 17 || distance_rightHand_lefthand > 45)
                else if (distance_leftHand_rightElbow > 20 || distance_rightHand_lefthand >= 45)
                {
                    Gesture6_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion


            #region Gesture 7 : leftHand and left Knee
            else if (leftHandJoint.Position.Y < leftelbowJoint.Position.Y && leftKnee.Position.Y > rightKnee.Position.Y)
            {
                var distance_leftHand_leftKnee = GetDistance(leftHandJoint, leftKnee);
                //tb_1.Text = distance_rightHand_leftElbow.ToString();
                if (distance_leftHand_leftKnee <= 15 && Gesture7_IsPerformed == false)
                {
                   // SoundPlayer p = new SoundPlayer(MediaFile);
                   // p.Play();

                    MusicSelector(GestureSounds.gestureSound7, SelectedInstrument);


                    Gesture7_IsPerformed = true;
                    BoneColor = Brushes.Red;

                }
                else if (distance_leftHand_leftKnee > 25)
                {
                    Gesture7_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion


            #region Gesture 8 : rightHand and right Knee
            else if (RightHandJoint.Position.Y < rightelbowJoint.Position.Y && rightKnee.Position.Y > leftKnee.Position.Y)
            {
                var distance_rightHand_rightKnee = GetDistance(RightHandJoint, rightKnee);
                //tb_1.Text = distance_rightHand_leftElbow.ToString();
                if (distance_rightHand_rightKnee <= 15 && Gesture8_IsPerformed == false)
                {
                    //SoundPlayer p = new SoundPlayer(MediaFile);
                    //p.Play();
                    MusicSelector(GestureSounds.gestureSound8, SelectedInstrument);

                    Gesture8_IsPerformed = true;
                    BoneColor = Brushes.Red;
                }
                else if (distance_rightHand_rightKnee > 25)
                {
                    Gesture8_IsPerformed = false;
                    BoneColor = Brushes.Black;
                }
            }
            #endregion


            //Not a working gesture.
            #region Gesture 5: Right Hand - left shoulder interaction
            ////RightHandJoint.Position.X < shoulderCenter.Position.X &&
            //// RightHandJoint.Position.Y > rightelbowJoint.Position.Y  &&
            //if (RightHandJoint.Position.X < shoulderCenter.Position.X   && RightHandJoint.Position.Y > rightelbowJoint.Position.Y)
            //{
            //    var distance_rightHand_leftShoulder = GetDistance(RightHandJoint,leftshoulder);
            //    //leftshoulder.Position.X >= RightHandJoint.Position.X &&
            //    if (  distance_rightHand_leftShoulder <=15 && Gesture5_IsPerformed==false)
            //    {

            //        SoundPlayer p = new SoundPlayer(MediaFile);
            //        p.Play();
            //        Gesture5_IsPerformed = true;

            //    }
            //    else if (distance_rightHand_leftShoulder > 25)
            //    {
            //        Gesture5_IsPerformed = false;
            //    }
            //}
            #endregion

            PianoPlayer(leftFoot,rightFoot);

            return true;
        }


        public void PianoPlayer(Joint leftFoot, Joint rightFoot)
        {

            var leftFootDepthPoint = this.sensorChooser.Kinect.CoordinateMapper.MapSkeletonPointToDepthPoint(leftFoot.Position, DepthImageFormat.Resolution640x480Fps30);
            var rightFootDepthPoint = this.sensorChooser.Kinect.CoordinateMapper.MapSkeletonPointToDepthPoint(rightFoot.Position, DepthImageFormat.Resolution640x480Fps30);

            //Perform the gesture according to given data
            //This is the extreme left gesture of the left foot
            if (leftFootDepthPoint.X >= 70 && leftFootDepthPoint.X < 100 && KeyPressed_1 == false)
            {
                //tb_applicationHeading.Text = "left foot on first key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound1, Instrument.Piano);
              
                KeyPressed_1 = true;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;


            }
            else if (leftFootDepthPoint.X > 100 && leftFootDepthPoint.X <= 130 && KeyPressed_2 == false)
            {
                //tb_applicationHeading.Text = "left foot on second key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound2, Instrument.Piano);
                KeyPressed_1 = false;
                KeyPressed_2 = true;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 130 && leftFootDepthPoint.X <= 160 && KeyPressed_3 == false)
            {
              //  tb_applicationHeading.Text = "left foot on third key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound3, Instrument.Piano);

                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = true;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 160 && leftFootDepthPoint.X <= 190 && KeyPressed_4 == false)
            {
               // tb_applicationHeading.Text = "left foot on fourth key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound4, Instrument.Piano);

                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = true;
                KeyPressed_5 = false;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 190 && leftFootDepthPoint.X <= 220 && KeyPressed_5 == false)
            {
                //tb_applicationHeading.Text = "left foot on fifth key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();
                MusicSelector(GestureSounds.footSound5, Instrument.Piano);
                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = true;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 220 && leftFootDepthPoint.X <= 250 && KeyPressed_6 == false)
            {
                //tb_applicationHeading.Text = "left foot on sixth key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();
                MusicSelector(GestureSounds.footSound6, Instrument.Piano);
                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = true;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 220 && leftFootDepthPoint.X <= 250 && KeyPressed_6 == false)
            {
                //tb_applicationHeading.Text = "left foot on seventh key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound7, Instrument.Piano);

                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = true;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else if (leftFootDepthPoint.X > 220 && leftFootDepthPoint.X <= 250 && KeyPressed_6 == false)
            {
                //tb_applicationHeading.Text = "left foot on eighth key";
                //SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                //player.Play();

                MusicSelector(GestureSounds.footSound8, Instrument.Piano);

                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = true;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
            else
            {
               // tb_applicationHeading.Text = "reset";
                KeyPressed_1 = false;
                KeyPressed_2 = false;
                KeyPressed_3 = false;
                KeyPressed_4 = false;
                KeyPressed_5 = false;
                KeyPressed_6 = false;
                KeyPressed_7 = false;
                KeyPressed_8 = false;
            }
        }

        private Polyline CreateFigure(Skeleton skeleton, JointType[] joints)
        {
            Polyline figure = new Polyline();
            figure.StrokeThickness = 5;
            figure.Stroke = BoneColor;
            for (int i = 0; i < joints.Length; i++)
            {
                figure.Points.Add(JointMapper(skeleton.Joints[joints[i]]));
            }
            return figure;
        }

        public double GetDistance(Joint firstJoint, Joint secondJoint)
        {
            var differenceX = firstJoint.Position.X - secondJoint.Position.X;
            var differenceY = firstJoint.Position.Y - secondJoint.Position.Y;
            var differenceZ = firstJoint.Position.Z - firstJoint.Position.Z;

            return (Math.Sqrt(differenceX * differenceX + differenceY * differenceY + differenceZ * differenceZ)) * 100;
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (this.sensorChooser.Kinect != null)
            {
                this.sensorChooser.Stop();
            }
        }

        //private void btn_instrument1_Click_1(object sender, RoutedEventArgs e)
        //{
        //    SelectedInstrument = Instrument.Drum;
        //    StatusBarUpdator();
        //}

        //private void btn_instrument2_Click_1(object sender, RoutedEventArgs e)
        //{
        //    SelectedInstrument = Instrument.Piano;
        //    StatusBarUpdator();
        //}

        private void StatusBarUpdator()
        {
            //sb_SelectedInstrument.Items.Clear();
            //sb_SelectedInstrument.Items.Add("Instrument -" + SelectedInstrument.ToString());
        }

    }
}
