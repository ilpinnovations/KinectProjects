﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Coding4Fun.Kinect.Wpf;
using Microsoft.Kinect;
using System.Windows.Shapes;
using System.Media;

namespace PlayPianoUsingKinect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    #region GestureSounds and Instruments
    enum GestureSounds
    {
        gestureSound1,
        gestureSound2,
        gestureSound3,
        gestureSound4,
        gestureSound5,
        gestureSound6,
        gestureSound7,
        gestureSound8
    }
    enum Instrument
    {
        Drum,
        Sexophone
    }

    #endregion
    public partial class MainWindow : Window
    {

        #region KinectDataHolders
        private readonly KinectSensor sensor;
        Skeleton[] totalSkeletons = new Skeleton[6];
        #endregion

        #region BitResetCollection
        private bool KeyPressed_1;
        private bool KeyPressed_2;
        private bool KeyPressed_3;
        private bool KeyPressed_4;
        private bool KeyPressed_5;
        private bool KeyPressed_6;
        private bool KeyPressed_7;
        private bool KeyPressed_8;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor == null)
                {
                    return;
                }

                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    sensor.SkeletonFrameReady += sensor_SkeletonFrameReady;
                    sensor.SkeletonStream.Enable();
                }

                if (sensor.ColorStream.IsEnabled == false)
                {
                    sensor.ColorFrameReady += sensor_ColorFrameReady;
                    sensor.ColorStream.Enable();
                }
                sensor.Start();
            
            }
            catch (Exception)
            {
                
                 //handle the error.
            }
        }

        void sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (var kinectColorFrame = e.OpenColorImageFrame())
            {
                if (kinectColorFrame ==null)
                {
                    return;
                }
                this.KinectImageControl.Source = kinectColorFrame.ToBitmapSource();
            }
        }

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame== null)
                {
                    return;
                }
                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }
                MapJointsToUIElement(firstSkeleton);
            }
        }

        private void MapJointsToUIElement(Skeleton firstSkeleton)
        {
            //Hands Mapping
            Point mappedRightHand = ScalePosition(firstSkeleton.Joints[JointType.HandRight].Position);
            Canvas.SetLeft(rightHandPointer, mappedRightHand.X);
            Canvas.SetTop(rightHandPointer, mappedRightHand.Y);

            Point mappedLeftHand = ScalePosition(firstSkeleton.Joints[JointType.HandLeft].Position);
            Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(leftHandPointer, mappedLeftHand.Y);

            //Foot mapping
            Point mappedLeftFeet = ScalePosition(firstSkeleton.Joints[JointType.FootLeft].Position);
            Canvas.SetLeft(leftFeetPointer, mappedLeftFeet.X);
            Canvas.SetTop(leftFeetPointer, mappedLeftFeet.Y);

            Point mappedRightFeet = ScalePosition(firstSkeleton.Joints[JointType.FootRight].Position);
            Canvas.SetLeft(rightFeetPointer, mappedRightFeet.X);
            Canvas.SetTop(rightFeetPointer, mappedRightFeet.Y);

            //Ankle Mapping
            Point mappedRightAnkle = ScalePosition(firstSkeleton.Joints[JointType.AnkleRight].Position);
            Canvas.SetLeft(rightAnklePointer,mappedRightAnkle.X);
            Canvas.SetTop(rightAnklePointer, mappedRightAnkle.Y);

            Point mappedLeftAnkle = ScalePosition(firstSkeleton.Joints[JointType.AnkleLeft].Position);
            Canvas.SetLeft(leftAnklePointer, mappedLeftAnkle.X);
            Canvas.SetTop(leftAnklePointer, mappedLeftAnkle.Y);

            //Knee Pointers
            Point mappedLeftKnee = ScalePosition(firstSkeleton.Joints[JointType.KneeLeft].Position);
            Canvas.SetLeft(leftKneePointer, mappedLeftKnee.X);
            Canvas.SetTop(leftKneePointer, mappedLeftKnee.Y);

            Point mappedRightKnee = ScalePosition(firstSkeleton.Joints[JointType.KneeRight].Position);
            Canvas.SetLeft(rightKneePointer, mappedRightKnee.X);
            Canvas.SetTop(rightKneePointer, mappedRightKnee.Y);

            FootMusicPlayer(firstSkeleton);
        }

        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            var depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint,DepthImageFormat.Resolution640x480Fps30);
            return new Point() {  X = depthImagePoint.X, Y = depthImagePoint.Y};
        }

        public void MediaPlayer(string fileLocation)
        {
            soundPlayer.Source = new Uri(fileLocation);
            soundPlayer.Play();
        }

        private void MusicSelector(GestureSounds sound, Instrument instrument)
        {
            if (instrument == Instrument.Drum)
            {
                //Loading the required files form file system.
                StringBuilder sb1 = new StringBuilder(System.AppDomain.CurrentDomain.BaseDirectory);
                sb1.Replace("\\bin\\Debug\\", "\\Sounds\\Drum");

                switch (sound)
                {
                    case GestureSounds.gestureSound1:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());
                        break;

                    case GestureSounds.gestureSound2:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());
                        break;
                    case GestureSounds.gestureSound3:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound4:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound5:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound6:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound7:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound8:
                        MediaPlayer(sb1.Append("\\Drum1.mp3").ToString());

                        break;
                    default:
                        MediaPlayer(string.Empty);
                        break;
                }

            }
            else if (instrument == Instrument.Sexophone)
            {
                StringBuilder sb2 = new StringBuilder(System.AppDomain.CurrentDomain.BaseDirectory);
                sb2.Replace("\\bin\\Debug\\", "\\Sounds\\Drum");

                switch (sound)
                {
                    case GestureSounds.gestureSound1:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());
                        break;

                    case GestureSounds.gestureSound2:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());
                        break;
                    case GestureSounds.gestureSound3:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound4:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound5:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound6:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound7:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    case GestureSounds.gestureSound8:
                        MediaPlayer(sb2.Append("\\Drum1.mp3").ToString());

                        break;
                    default:
                        MediaPlayer(string.Empty);
                        break;
                }
            }
        }


        public void FootMusicPlayer(Skeleton  musicalSkeleton)
        {

            if (musicalSkeleton.Joints[JointType.FootRight].TrackingState == JointTrackingState.Tracked && musicalSkeleton.Joints[JointType.FootLeft].TrackingState == JointTrackingState.Tracked )
            {
                //soundPlayer.Source = new Uri(@"C:\Users\ARVIND\Desktop\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\Drum1.mp3");
                //soundPlayer.Play();
                //txt_information.Text = string.Format( "Left Foot X:{0} Y:{1} Right Foot X:{3} Y:{3}",trackedPoints[0].X,trackedPoints[0].Y,trackedPoints[1].X,trackedPoints[1].Y);


                var leftFoot = musicalSkeleton.Joints[JointType.FootLeft];
                var rightFoot = musicalSkeleton.Joints[JointType.FootRight];


                var leftFootDepthPoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(leftFoot.Position, DepthImageFormat.Resolution640x480Fps30);
                var rightFootDepthPoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(rightFoot.Position,DepthImageFormat.Resolution640x480Fps30);

                txt_information1.Text = string.Format( "Left Foot X:{0} Y:{1} Depth:{2}",leftFootDepthPoint.X,leftFootDepthPoint.Y,leftFootDepthPoint.Depth.ToString());
                txt_information2.Text = string.Format("Right Foot X:{0} Y:{1} Depth:{2}",rightFootDepthPoint.X, rightFootDepthPoint.Y, rightFootDepthPoint.Depth.ToString());
               
                //txt_information.Text = string.Format("Left Foot X:{0} Y:{1} Z:{3} Right Foot X:{3} Y:{4} Z:{5}"  , Math.Round( leftFoot.Position.X,3), Math.Round( leftFoot.Position.Y,3) , depthPoint.Depth,
                //    Math.Round( rightFoot.Position.X,3) , Math.Round( rightFoot.Position.Y,3), Math.Round( rightFoot.Position.Z,3));


                //Data and gesture is not precise
                //if (leftFoot.Position.X > -1.260 && leftFoot.Position.X < -1.200  && leftFoot.Position.Z < 2.90)
                //{
                //    tb_applicationHeading.Text = "Gesture Performed left foot detected";
                //}
                //else
                //{
                //    tb_applicationHeading.Text = "Application Heading";
                //}



                //Perform the gesture according to given data
                //This is the extreme left gesture of the left foot
                if (leftFootDepthPoint.X >= 70 && leftFootDepthPoint.X < 100 && KeyPressed_1 == false )
                {
                    //tb_applicationHeading.Text = "left foot on first key";
                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();


                    //MusicSelector(GestureSounds.gestureSound8, SelectedInstrument);

                    KeyPressed_1 = true;
                    KeyPressed_2 = false;
                    KeyPressed_3 = false;
                    KeyPressed_4 = false;
                    KeyPressed_5 = false;
                    KeyPressed_6 = false;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;


                }
                else if(leftFootDepthPoint.X >100 && leftFootDepthPoint.X <= 130 && KeyPressed_2== false)
                {
                    //tb_applicationHeading.Text = "left foot on second key";
                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();
                    KeyPressed_1 = false;
                    KeyPressed_2 = true;
                    KeyPressed_3 = false;
                    KeyPressed_4 = false;
                    KeyPressed_5 = false;
                    KeyPressed_6 = false;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;
                }
                else if(leftFootDepthPoint.X > 130 && leftFootDepthPoint.X <= 160 && KeyPressed_3 == false)
                {
                    tb_applicationHeading.Text = "left foot on third key";
                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();
                    KeyPressed_1 = false;
                    KeyPressed_2 = false;
                    KeyPressed_3 = true;
                    KeyPressed_4 = false;
                    KeyPressed_5 = false;
                    KeyPressed_6 = false;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;
                }
                else if (leftFootDepthPoint.X > 160 && leftFootDepthPoint.X <= 190 && KeyPressed_4 == false)
                {
                    tb_applicationHeading.Text = "left foot on fourth key";
                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();
                    KeyPressed_1 = false;
                    KeyPressed_2 = false;
                    KeyPressed_3 = false;
                    KeyPressed_4 = true;
                    KeyPressed_5 = false;
                    KeyPressed_6 = false;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;
                }
                else if (leftFootDepthPoint.X > 190 && leftFootDepthPoint.X <= 220 && KeyPressed_5== false)
                {
                    tb_applicationHeading.Text = "left foot on fifth key";
                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();
                    KeyPressed_1 = false;
                    KeyPressed_2 = false;
                    KeyPressed_3 = false;
                    KeyPressed_4 = false;
                    KeyPressed_5 = true;
                    KeyPressed_6 = false;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;
                }
                else if (leftFootDepthPoint.X > 220 && leftFootDepthPoint.X <= 250 && KeyPressed_6 == false)
                {
                    tb_applicationHeading.Text = "left foot on sixth key";

                    SoundPlayer player = new SoundPlayer(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\PlayPianoUsingKinect\PlayPianoUsingKinect\Sounds\file.wav");
                    player.Play();
                    KeyPressed_1 = false;
                    KeyPressed_2 = false;
                    KeyPressed_3 = false;
                    KeyPressed_4 = false;
                    KeyPressed_5 = false;
                    KeyPressed_6 = true;
                    KeyPressed_7 = false;
                    KeyPressed_8 = false;
                }
                else
                {
                    tb_applicationHeading.Text = "reset";
                }
            }
        }

        private void Window_Closed_1(object sender, EventArgs e)
        {
            if (sensor != null)
            {
                sensor.Stop();
            }
        }

    }
}
