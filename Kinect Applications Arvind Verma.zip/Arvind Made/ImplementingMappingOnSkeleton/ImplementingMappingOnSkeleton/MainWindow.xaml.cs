﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.Kinect;
using Coding4Fun.Kinect.Wpf;
using System.Windows.Shapes;


namespace ImplementingMappingOnSkeleton
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region KinectObjects
        KinectSensor sensor;
        Skeleton[] totalSkeletons = new Skeleton[6];
        float skeletonMaxX = 1.0f;
        float skeletonMaxY = 1.0f;
        //Line skeletonBone = new Line();
        int elementCounter;
        #endregion
        public MainWindow()
        {
            InitializeComponent();

            elementCounter = KinectCanvas.Children.Count;
            tb_canvasElementCount.Text = KinectCanvas.Children.Count.ToString();


            sensor = KinectSensor.KinectSensors.FirstOrDefault(sense => sense.Status == KinectStatus.Connected);
            if (sensor == null)
            {
                return;
            }

            if (sensor.SkeletonStream.IsEnabled == false)
            {
                sensor.SkeletonStream.Enable();
                sensor.SkeletonFrameReady += sensor_SkeletonFrameReady;
            }

            //if (sensor.ColorStream.IsEnabled == false)
            //{
            //    sensor.ColorStream.Enable();
            //    sensor.ColorFrameReady += sensor_ColorFrameReady;
            //}
            sensor.Start();
            //sensor.ElevationAngle = 0;
        }

        

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                tb_canvasElementCount.Text = KinectCanvas.Children.Count.ToString();
                if (skeletonFrame == null)
                {
                    return;
                }
                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                var firstSkeleton = totalSkeletons.FirstOrDefault(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked);
                if (firstSkeleton == null)
                {
                    return;
                }

                //rigth arm 
                KinectCanvas.Children.Add(CreateFigure(firstSkeleton, Brushes.LightGreen, new JointType[] {  JointType.ShoulderRight, JointType.ElbowRight,
JointType.WristRight, JointType.HandRight }));

                //left arm
                KinectCanvas.Children.Add(CreateFigure(firstSkeleton, Brushes.LightGreen, new JointType[] {  JointType.ShoulderLeft, JointType.ElbowLeft,
JointType.WristLeft, JointType.HandLeft }));

                //head and middle body.
                KinectCanvas.Children.Add(CreateFigure(firstSkeleton, Brushes.LightGreen, new JointType[]{ JointType.Head, JointType.ShoulderCenter,
                JointType.ShoulderLeft, JointType.Spine,
                JointType.ShoulderRight, JointType.ShoulderCenter,
                JointType.HipCenter, JointType.HipLeft,
                JointType.Spine, JointType.HipRight,
                JointType.HipCenter}));

                //left leg
                KinectCanvas.Children.Add(CreateFigure(firstSkeleton, Brushes.LightGreen, new JointType[]{ JointType.HipLeft, JointType.KneeLeft,
                JointType.AnkleLeft, JointType.FootLeft}));

                //right leg
                KinectCanvas.Children.Add(CreateFigure(firstSkeleton, Brushes.LightGreen, new JointType[]{ JointType.HipRight, JointType.KneeRight,
                JointType.AnkleRight, JointType.FootRight}));


                //adjusting the width of the image.
                this.img_Mapped.Width = GetDistance(firstSkeleton.Joints[JointType.ShoulderLeft], firstSkeleton.Joints[JointType.ShoulderRight]);

                MapSkeletonToUIElements(firstSkeleton);

                //removing the bones after drawing.
                for (int i = 1; i < 6; i++)
                {
                    KinectCanvas.Children.RemoveAt(elementCounter - i);
                }
            }
        }

        private Point JointMapper(Joint trackedJoint)
        {
            var scaledJoint = trackedJoint.ScaleTo(
                  Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenWidth),
                 Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenHeight),
                 skeletonMaxX,
                 skeletonMaxY
                 );

            return new Point() { X = scaledJoint.Position.X, Y = scaledJoint.Position.Y };
        }


        private double GetDistance(Joint firstJoint, Joint secondJoint)
        {
            var differenceX = firstJoint.Position.X - secondJoint.Position.X;
            var differenceY = firstJoint.Position.Y - secondJoint.Position.Y;
            var differenceZ = firstJoint.Position.Z - firstJoint.Position.Z;

            return Math.Sqrt(differenceX * differenceX + differenceY * differenceY + differenceZ * differenceZ) * 800;
        }
        //used for mapping conversion of  the skeleton. (3D -> 2D conversion)
        private System.Windows.Point JointMapper(Joint trackedJoint, UIElement JointPresenter)
        {
            var mappedJoint = trackedJoint.ScaleTo(
                 Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenWidth),
                Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenHeight),
                skeletonMaxX,
                skeletonMaxY
                );

            Canvas.SetLeft(JointPresenter, mappedJoint.Position.X);
            Canvas.SetTop(JointPresenter, mappedJoint.Position.Y);

            return new System.Windows.Point() { X = mappedJoint.Position.X, Y = mappedJoint.Position.Y };
        }
        private void MapSkeletonToUIElements(Skeleton firstSkeleton)
        {
            //mapping the right hand
            JointMapper(JointPresenter: rightHandPointer, trackedJoint: firstSkeleton.Joints[JointType.HandRight]);
            //mapping the left hand
            JointMapper(firstSkeleton.Joints[JointType.HandLeft], leftHandPointer);

            //mapping the left shoulder 
            JointMapper(firstSkeleton.Joints[JointType.ShoulderLeft], this.leftShoulderPointer);

            //mapping the image 
            //JointMapper(firstSkeleton.Joints[JointType.ShoulderLeft], this.img_Mapped);

            //mapping thr right shoulder
            JointMapper(firstSkeleton.Joints[JointType.ShoulderRight], this.rightShoulderPointer);

            //mapping of head
            JointMapper(firstSkeleton.Joints[JointType.Head], this.headPointer);

            //mapping of shoulderCenter
            JointMapper(firstSkeleton.Joints[JointType.ShoulderCenter], this.shoulderCenterPointer);

            //mapping for left elbow
            JointMapper(firstSkeleton.Joints[JointType.ElbowLeft], this.leftElbowPointer);

            //mapping of right elbow
            JointMapper(firstSkeleton.Joints[JointType.ElbowRight], this.rightElbowPointer);

            //mapping of right wrist
            JointMapper(firstSkeleton.Joints[JointType.WristRight], this.rightWristPointer);

            //mapping of left wrist
            JointMapper(firstSkeleton.Joints[JointType.WristLeft], this.leftWristPointer);

            //mapping of spine joint
            JointMapper(firstSkeleton.Joints[JointType.Spine], this.spinePointer);

            //mapping of left hip joint
            JointMapper(firstSkeleton.Joints[JointType.HipLeft], this.leftHipJointPointer);

            //mapping of right hip joint
            JointMapper(firstSkeleton.Joints[JointType.HipRight], this.rightHipJointPointer);

            //mapping of center hip joint
            JointMapper(firstSkeleton.Joints[JointType.HipCenter], this.centerHipJoint);

            //mapping of knees
            JointMapper(firstSkeleton.Joints[JointType.KneeLeft], this.leftKneePointer);
            JointMapper(firstSkeleton.Joints[JointType.KneeRight], this.rightKneePointer);

            //mapping of ankles
            JointMapper(firstSkeleton.Joints[JointType.AnkleLeft], this.leftAnklePointer);
            JointMapper(firstSkeleton.Joints[JointType.AnkleRight], this.rightAnklePointer);

            //mapping of foot
            JointMapper(firstSkeleton.Joints[JointType.FootLeft], this.leftFootPointer);
            JointMapper(firstSkeleton.Joints[JointType.FootRight], this.rightFootPointer);

            #region Relative Motion of image
            Joint mappedRightShoulder = firstSkeleton.Joints[JointType.ShoulderRight].ScaleTo(Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenWidth),
                Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenHeight),
                skeletonMaxX,
                skeletonMaxY);

            Canvas.SetRight(img_Mapped, mappedRightShoulder.Position.X);
            Canvas.SetTop(img_Mapped, mappedRightShoulder.Position.Y);
            #endregion
        }
        //Drawing bones using polyline.
        private Polyline CreateFigure(Skeleton skeleton, Brush brush, JointType[] joints)
        {
            Polyline figure = new Polyline();
            figure.StrokeThickness = 10;
            figure.Stroke = brush;
            for (int i = 0; i < joints.Length; i++)
            {
                figure.Points.Add(JointMapper(skeleton.Joints[joints[i]]));
            }
            return figure;
        }

    }
}
