﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Kinect;
using System.Threading.Tasks;
using System.Net;

namespace SPARK
{
    public static class Extensions
    {
        public static double GetDistance(this Joint firstJoint, Joint secondJoint)
        {
            var differenceX = firstJoint.Position.X - secondJoint.Position.X;
            var differenceY = firstJoint.Position.Y - secondJoint.Position.Y;
            var differenceZ = firstJoint.Position.Z - secondJoint.Position.Z;

            return Math.Round(100 * Math.Sqrt(differenceX * differenceX + differenceY * differenceY + differenceZ * differenceZ), 3);
        }

        public static void DataSender(this string Key1, string Value1, string Key2, string Value2, string URL)
        {
            var webclient = new WebClient();
            webclient.DownloadStringAsync(new Uri(URL + "?" + Key1 + "=" + Value1 + "&" + Key2 + "=" + Value2));
        }
    }
}
