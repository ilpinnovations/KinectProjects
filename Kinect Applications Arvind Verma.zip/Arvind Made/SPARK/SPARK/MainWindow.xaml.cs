﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Kinect;
using System.Collections.Generic;


namespace SPARK
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region KinectDataHolders
        KinectSensor sensor;
        Skeleton[] totalSkeleton = new Skeleton[6];
        string URL_setDirection = "http://192.168.169.101/pi/setdirections.php";
        #endregion

        public MainWindow()
        {
            InitializeComponent();
            //Kinect Boilder Plate
            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor == null)
                {
                    return;
                }

                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    TransformSmoothParameters parameters = new TransformSmoothParameters()
                    {
                        //Correction = 0.5f,
                        //Prediction = 0.4f,
                        //Smoothing = 0.9f                     
                    };
                    sensor.SkeletonFrameReady += Sensor_SkeletonFrameReady;
                    sensor.SkeletonStream.Enable();
                }

                if (sensor.DepthStream.IsEnabled == false)
                {
                    sensor.DepthFrameReady += Sensor_DepthFrameReady;
                    sensor.DepthStream.Enable();
                }

                //Setting the sensor elevation angle.


                sensor.Start();
                sensor.ElevationAngle = 5;
            }
            catch (Exception)
            {
                // txt_information1.Text = "asdflj";
                //supress the exception
            }
        }

        private void Sensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            //throw new NotImplementedException();
        }

        private void Sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeleton);
                var driver = totalSkeleton.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (driver == null)
                {
                    return;
                }

                MapSkeletonJointsToUIElement(driver);
            }
        }

        private void MapSkeletonJointsToUIElement(Skeleton driver)
        {
            Dictionary<string, Joint> JointDictionary = new Dictionary<string, Joint>()
            {
                {"rightHand",driver.Joints[JointType.HandRight] },
                {"leftHand",driver.Joints[JointType.HandLeft]},
                { "head",driver.Joints[JointType.Head]},
                { "leftElbow",driver.Joints[JointType.ElbowLeft]},
                { "rightElbow",driver.Joints[JointType.ElbowRight]},
                { "rightShoulder",driver.Joints[JointType.ShoulderRight]},
                { "leftShoulder", driver.Joints[JointType.ShoulderLeft]},
                { "shoulderCenter",driver.Joints[JointType.ShoulderCenter]}
            };

            //Getting the joints on the user interface
            Point mappedrightHand = ScalePosition(JointDictionary["rightHand"].Position);
            Canvas.SetLeft(rightHandPointer, mappedrightHand.X);
            Canvas.SetTop(rightHandPointer, mappedrightHand.Y);

            Point mappedLeftHand = ScalePosition(JointDictionary["leftHand"].Position);
            Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(leftHandPointer, mappedLeftHand.Y);

            Point mappedHead = ScalePosition(JointDictionary["head"].Position);
            Canvas.SetLeft(headPointer, mappedHead.X);
            Canvas.SetTop(headPointer, mappedHead.Y);

            Point mappedLeftElbow = ScalePosition(JointDictionary["leftElbow"].Position);
            Canvas.SetLeft(leftElbowPointer, mappedLeftElbow.X);
            Canvas.SetTop(leftElbowPointer, mappedLeftElbow.Y);

            Point mappedRightElbow = ScalePosition(JointDictionary["rightElbow"].Position);
            Canvas.SetLeft(rightElbowPointer, mappedRightElbow.X);
            Canvas.SetTop(rightElbowPointer, mappedRightElbow.Y);

            //Gesture Validator
            GestureValidator(JointDictionary);

        }

        private void GestureValidator(Dictionary<string,Joint> JointDictionary)
        {
            if (JointDictionary["rightHand"].Position.Y < JointDictionary["rightElbow"].Position.Y && JointDictionary["leftHand"].Position.Y < JointDictionary["leftElbow"].Position.Y)
            {
                //Car is stop
                //nothing is gonna do do
                "left".DataSender("2","forward","2",URL_setDirection);
                txt_information1.Text = "Car is stop";
            }
            else if (JointDictionary["leftHand"].Position.Y < JointDictionary["leftElbow"].Position.Y && JointDictionary["rightHand"].Position.Y > JointDictionary["rightElbow"].Position.Y)
            {
                //Go Forward and turn according the position of the right hand
                var distance_Head_RightHand = Convert.ToInt32(JointDictionary["rightHand"].GetDistance(JointDictionary["head"]));
                var distance_rightShoulder_rightHand = Convert.ToInt32(JointDictionary["rightHand"].GetDistance(JointDictionary["rightShoulder"]));
                var distance_shoulderCenter_rightHand = Convert.ToInt32(JointDictionary["rightHand"].GetDistance(JointDictionary["shoulderCenter"]));
                var distance_leftShoulder_rightHand = Convert.ToInt32(JointDictionary["rightHand"].GetDistance(JointDictionary["leftShoulder"]));

               // txt_information1.Text = distance_Head_RightHand.ToString() + " Head-RH";
                txt_information2.Text = distance_rightShoulder_rightHand.ToString() + " RS-RH";
                txt_information3.Text = distance_shoulderCenter_rightHand.ToString() + " SC-RH";
                txt_information4.Text = distance_leftShoulder_rightHand+" LS-RH";

                if (distance_leftShoulder_rightHand > 70 && JointDictionary["rightHand"].Position.X > JointDictionary["rightElbow"].Position.X)
                {
                    //right turn
                    txt_information1.Text = "right forward";

                    //"right".DataSender("1", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("0", URL_setDirection);
                    //"back".DataSender("0", URL_setDirection);

                    "right".DataSender("1", "forward", "0", URL_setDirection);

                }
                else if (distance_leftShoulder_rightHand < 34 && JointDictionary["rightHand"].Position.X < JointDictionary["rightElbow"].Position.X)
                {
                    //left turn
                    txt_information1.Text = "left forward";
                    //"right".DataSender("0", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("0", URL_setDirection);
                    //"back".DataSender("0", URL_setDirection);
                    "left".DataSender("0", "forward", "0", URL_setDirection);
                }
                else if (distance_leftShoulder_rightHand <70  && distance_leftShoulder_rightHand> 34 )
                {
                    txt_information1.Text = "moving forward";

                    //"right".DataSender("2", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("0", URL_setDirection);
                    //"back".DataSender("0", URL_setDirection);

                    "right".DataSender("2", "forward", "0", URL_setDirection);
                }
            }

            else if (JointDictionary["leftHand"].Position.Y > JointDictionary["leftElbow"].Position.Y && JointDictionary["rightHand"].Position.Y > JointDictionary["rightElbow"].Position.Y)
            {
                //go back and turn according to right hand position.
                //txt_information1.Text = "Backward";
                var distance_leftShoulder_rightHand = Convert.ToInt32(JointDictionary["rightHand"].GetDistance(JointDictionary["leftShoulder"]));

                if (distance_leftShoulder_rightHand > 70 && JointDictionary["rightHand"].Position.X > JointDictionary["rightElbow"].Position.X)
                {
                    txt_information1.Text = "right backward";
                    //"right".DataSender("1", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("0", URL_setDirection);
                    //"back".DataSender("1", URL_setDirection);

                    "right".DataSender("1","back","1",URL_setDirection);

                }
                else if (distance_leftShoulder_rightHand < 34 && JointDictionary["rightHand"].Position.X < JointDictionary["rightElbow"].Position.X)
                {
                    txt_information1.Text = "left backward";
                    //"right".DataSender("0", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("1", URL_setDirection);
                    //"back".DataSender("1", URL_setDirection);

                    "left".DataSender("0", "back", "1", URL_setDirection);
                }
                else if (distance_leftShoulder_rightHand < 70 && distance_leftShoulder_rightHand > 34)
                {
                    txt_information1.Text = "moving backward";
                    //"right".DataSender("0", URL_setDirection);
                    //"forward".DataSender("0", URL_setDirection);
                    //"left".DataSender("0", URL_setDirection);
                    //"back".DataSender("1", URL_setDirection);
                    "back".DataSender("1", "right", "2", URL_setDirection);
                }

            }
        }


        private Point ScalePosition(SkeletonPoint position)
        {

            //we can use the depth of point for better control of the car. depth from the kinect sensor.
            var depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(position, DepthImageFormat.Resolution640x480Fps30);
            return new Point() { X = depthImagePoint.X, Y = depthImagePoint.Y };
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            if (sensor != null)
            {
                sensor.Stop();
            } 
        }
    }
}
