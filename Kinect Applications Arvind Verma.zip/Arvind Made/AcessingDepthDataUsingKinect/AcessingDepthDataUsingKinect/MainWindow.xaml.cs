﻿using System.Windows;
using System.Linq;
using Microsoft.Kinect;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System;
namespace AcessingDepthDataUsingKinect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region KINECT Data Holders 
        private KinectSensor sensor;
        short[] pixelData;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
        }

        private void ApplicationWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //Make sure that sensor is connected to computer and powered up.
            //Getting the sensor in application using LINQ
            sensor = KinectSensor.KinectSensors.Where(sense =>
            sense.Status == KinectStatus.Connected).FirstOrDefault();
            //Checking the DepthStream.
            if (sensor.DepthStream.IsEnabled == false)
            {
                sensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);
            }
               //No need to run the application.
            else
            {
                return;
            }
            //Publishing the Event for Depth Data.
            sensor.DepthFrameReady += new System.EventHandler<DepthImageFrameReadyEventArgs>(sensor_DepthFrameReady);
            sensor.Start();
        }

        void sensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            //Accessing the current frame as well as disposing it after processing.
            using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
            {
                
                if (depthImageFrame== null)
                {
                  //Something went wrong. Not getting the data from sensor.
                    return;
                }
                //Getting the data.
                pixelData = new short[depthImageFrame.PixelDataLength];
                
                int stride = depthImageFrame.Width * 2;
                depthImageFrame.CopyPixelDataTo(pixelData);
                depthImageControl.Source = BitmapSource.Create(depthImageFrame.Width, depthImageFrame.Height, 
                    96, 96, PixelFormats.Gray16, null, pixelData, stride);
            }
        }

        //calculating the distance from a particular pixel on mouse down event.
        private void depthImageControl_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Point currentPoint = e.GetPosition(this.depthImageControl);
            //calculating pixel index.
            int PixelIndex = System.Convert.ToInt32(currentPoint.X + Convert.ToInt32(currentPoint.Y * depthImageControl.Width));//Look at it.
            int distanceIn_mm = this.pixelData[PixelIndex] >> DepthImageFrame.PlayerIndexBitmaskWidth;
            tb_distance_mm.Text = distanceIn_mm.ToString();
        }

        //calculating the distance from a particular pixel on mouse move event.
        private void depthImageControl_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            Point currentPoint = e.GetPosition(this.depthImageControl);
            //calculating pixel index.
            int PixelIndex = System.Convert.ToInt32(currentPoint.X + Convert.ToInt32(currentPoint.Y * depthImageControl.Width));//Look at it.
            int distanceIn_mm = this.pixelData[PixelIndex] >> DepthImageFrame.PlayerIndexBitmaskWidth;
            tb_distance_mm.Text = distanceIn_mm.ToString();

        }

    }
}
