﻿using System;
using System.Collections.Generic;
using System.Linq;

using System.Windows;
using System.Windows.Controls;
using Microsoft.Kinect;
using System.Net;

using System.IO;
using System.Drawing;
using System.Collections.Specialized;


namespace FileSender
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region KinectDataHolders
        KinectSensor sensor;
        Skeleton[] totalSkeleton = new Skeleton[6];
        bool isFileTransferGesturePerformed = false;
        int temp_value = 0;
        #endregion
        public MainWindow()
        {
            InitializeComponent();


            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor == null)
                {
                    return;
                }

                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    sensor.SkeletonStream.Enable();
                    sensor.SkeletonFrameReady += Sensor_SkeletonFrameReady;
                }
                sensor.Start();
            }
            catch (Exception exp)
            {

                MessageBox.Show(exp.Message);
            }

           

        }

        private void Sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeleton);
                var firstSkeleton = totalSkeleton.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                MapJointsToUIElement(firstSkeleton);
            }
        }

        private void MapJointsToUIElement(Skeleton firstSkeleton)
        {

            var rightHand = firstSkeleton.Joints[JointType.HandRight];
            var leftHand = firstSkeleton.Joints[JointType.HandLeft];
            var leftElbow = firstSkeleton.Joints[JointType.ElbowLeft];
            var rightElbow = firstSkeleton.Joints[JointType.ElbowRight];

            System.Windows.Point mappedRightHand = ScalePosition(rightHand.Position);
            Canvas.SetLeft(this.rightHandPointer,mappedRightHand.X);
            Canvas.SetTop(this.rightHandPointer, mappedRightHand.Y);

            System.Windows.Point mappedLeftHand = ScalePosition(leftHand.Position);
            Canvas.SetLeft(this.leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(this.leftHandPointer, mappedLeftHand.Y);

            System.Windows.Point mappedleftElbow = ScalePosition(leftElbow.Position);
            Canvas.SetLeft(this.leftElbowPointer, mappedleftElbow.X);
            Canvas.SetTop(this.leftElbowPointer, mappedleftElbow.Y);

            System.Windows.Point mappedrightElbow = ScalePosition(rightElbow.Position);
            Canvas.SetLeft(this.rightElbowPointer, mappedrightElbow.X);
            Canvas.SetTop(this.rightElbowPointer, mappedrightElbow.Y);

            //perfect the gesture with distance calculation.

            if (rightHand.Position.Y > rightElbow.Position.Y)
            {
                if (rightElbow.Position.Y > leftElbow.Position.Y && rightHand.Position.X < leftElbow.Position.X && isFileTransferGesturePerformed == false)
                {

                    PHPFileSender();
                    isFileTransferGesturePerformed = true;


                }
            }
            else if ( rightHand.Position.X > leftElbow.Position.X)
            {
                isFileTransferGesturePerformed = false;
            }

            
           
        }

        public void GestureEncoder()
        {

        }

        private System.Windows.Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            var depthImagePoint = sensor.MapSkeletonPointToDepth(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            return new System.Windows.Point() { X = depthImagePoint.X, Y = depthImagePoint.Y };
        }

        public void PHPFileSender()
        {
            temp_value++;
           System.Drawing.Image myImage = temp_value%2==0?  GetImage("http://localhost/image1.jpg") : GetImage("http://localhost/image2.jpg");

            // Convert to base64 encoded string
            string base64Image = ImageToBase64(myImage, System.Drawing.Imaging.ImageFormat.Jpeg);

            // Post image to upload handler
            using (WebClient client = new WebClient())
            {
                byte[] response = client.UploadValues("http://192.168.1.103/image/upload.php", new NameValueCollection()
                {
                    { "myImageData", base64Image }
                });

                //Console.WriteLine("Server Said: " + System.Text.Encoding.Default.GetString(response));
            }
        }



        static System.Drawing.Image GetImage(string filePath)
        {
            WebClient l_WebClient = new WebClient();
            byte[] l_imageBytes = l_WebClient.DownloadData(filePath);
            MemoryStream l_stream = new MemoryStream(l_imageBytes);
            return System.Drawing.Image.FromStream(l_stream);
        }

        static string ImageToBase64(System.Drawing.Image image, System.Drawing.Imaging.ImageFormat format)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                // Convert Image to byte[]
                image.Save(ms, format);
                byte[] imageBytes = ms.ToArray();

                // Convert byte[] to Base64 String
                string base64String = Convert.ToBase64String(imageBytes);
                return base64String;
            }
        }



    }
}
