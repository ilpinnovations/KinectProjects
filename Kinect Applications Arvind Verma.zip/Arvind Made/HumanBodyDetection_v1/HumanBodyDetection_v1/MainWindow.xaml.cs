﻿#region Namespaces
using System.Windows;
using Microsoft.Kinect;
using System.Linq;
using System.Windows.Media.Imaging;
using System.Windows.Media;
using System.Windows.Controls;
using System;
using System.Windows.Forms;
using System.Speech.Synthesis;
using System.Threading;
using System.IO;
using System.Windows.Threading;
using System.ComponentModel;
using System.Windows.Shapes;
using System.Collections.Generic;
#endregion


namespace HumanBodyDetection_v1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        #region Kinect Objects and Data Holders
        int bodyCount;
       
        private KinectSensor sensor;
        private Skeleton[] totalSkeleton = new Skeleton[6]; //maximum skeleton can be detected.
        DispatcherTimer timer = new DispatcherTimer();
        List<int> BonesIndexList = new List<int>();
        #endregion

        

        public MainWindow()
        {
            InitializeComponent();
            
            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor.SkeletonStream.IsEnabled == false && sensor.ColorStream.IsEnabled == false && sensor.DepthStream.IsEnabled == false)
                {
                    //Enabling the Depth Stream
                    //sensor.DepthStream.Enable();
                    //Registering the DepthFrameReady Event.
                    sensor.DepthFrameReady += new System.EventHandler<DepthImageFrameReadyEventArgs>(sensor_DepthFrameReady);

                    //Enabling the skeleton stream.
                    sensor.SkeletonStream.Enable();
                    sensor.SkeletonFrameReady += new System.EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);

                    //Enabling the Color Stream.
                    //sensor.ColorStream.Enable();
                    //registerting the colorFrameReady Event.
                    sensor.ColorFrameReady += new System.EventHandler<ColorImageFrameReadyEventArgs>(sensor_ColorFrameReady);
                }

                sensor.Start();
                sensor.ElevationAngle = 0;//Calibration is required.
                
            }
            catch (System.Exception exp)
            {
                System.Windows.MessageBox.Show("Technical Error - " + exp.Message);
            }

        }

        void sensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        {
            using (var depthImageFrame = e.OpenDepthImageFrame())
            {
                if (depthImageFrame == null)
                {
                    return;
                }
                //Reading the data from the device.
                short[] pixelData = new short[depthImageFrame.PixelDataLength];
                int stride = depthImageFrame.Width * 2;
                depthImageFrame.CopyPixelDataTo(pixelData);
                depthImageControl.Source = BitmapSource.Create(depthImageFrame.Width,

                    depthImageFrame.Height,
                    96, 96,
                    PixelFormats.Gray16,
                    null,
                    pixelData,
                    stride);
            }
        }

        void sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
            {

                
                if (colorImageFrame == null)
                {
                    return;
                }
                var pixelData = new byte[colorImageFrame.PixelDataLength];
                colorImageFrame.CopyPixelDataTo(pixelData);

                int stride = colorImageFrame.Width * colorImageFrame.BytesPerPixel;

                colorImageControl.Source = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height,
                    96, 96, PixelFormats.Bgr32, null, pixelData, stride);
            }
        }


        private void SaveImage()
        {
            using (FileStream fs = new FileStream(@"c:\users\arvindtheadmin\desktop\arving.jpg", FileMode.Create))
            {
                BitmapSource imageSource = (BitmapSource)colorImageControl.Source;
                JpegBitmapEncoder jpegEncoder = new JpegBitmapEncoder();
                jpegEncoder.Frames.Add(BitmapFrame.Create(imageSource));
                jpegEncoder.Save(fs);
                fs.Close();
            }
        }


        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeleton);
                //tb_bodyCounter.Text = totalSkeleton.Count(skeleton => skeleton.Joints[JointType.Head].TrackingState == JointTrackingState.Tracked).ToString();
                bodyCount = totalSkeleton.Count(skeleton_count => skeleton_count.TrackingState == SkeletonTrackingState.Tracked);
                tb_bodyCounter.Text = "Total Count - " + bodyCount.ToString();


                //Complete bodyscan can be placed here.
                if (bodyCount == 1)
                {
                    


                    Skeleton firstSkeleton = totalSkeleton.Where(detectedSkeleton => detectedSkeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();
                    if (firstSkeleton.TrackingState == SkeletonTrackingState.Tracked)
                    {
                        tb_information.Text = "Tracking ID - " + firstSkeleton.TrackingId.ToString();

                        if (sensor.ColorStream.IsEnabled == false)
                        {
                            sensor.ColorStream.Enable();
                            colorImageControl.Visibility = System.Windows.Visibility.Visible;

                           

                        }
                        if (sensor.DepthStream.IsEnabled == false)
                        {
                            sensor.DepthStream.Enable();
                            depthImageControl.Visibility = System.Windows.Visibility.Visible;
                        }
                        MapJointsWithUIElements(firstSkeleton);
                        skeletonCanvas.Visibility = System.Windows.Visibility.Visible;
                    }

                    if (firstSkeleton.Joints[JointType.HandRight].Position.Y > firstSkeleton.Joints[JointType.ShoulderCenter].Position.Y)
                    {
                        tb_bodyCounter.Text = "Hello Kinect";
                    }

                    if (firstSkeleton.Joints[JointType.HandLeft].Position.Y > firstSkeleton.Joints[JointType.ElbowLeft].Position.Y && firstSkeleton.Joints[JointType.HandRight].Position.Y > firstSkeleton.Joints[JointType.ElbowRight].Position.Y)
                    {
                        var distance = Convert.ToInt32(GetDistance(firstSkeleton.Joints[JointType.HandLeft], firstSkeleton.Joints[JointType.HandRight]) * 100); //in cms;
                        // rec_GestureEnabled.Width = distance;
                        //rec_GestureEnabled.Height = distance;
                        tb_HandsDistance.Text = distance.ToString() + " in cms";

                        if (distance == 80)
                        {
                            //PERFORM DESIERED OPERATION. Capture Image
                            

                            //Thread t = new Thread(new ThreadStart(SaveImage));
                            //t.Start();
                            //t.Join();

                        }

                        var distanceBetweenElbows = Convert.ToInt32(GetDistance(firstSkeleton.Joints[JointType.ElbowLeft], firstSkeleton.Joints[JointType.ElbowRight]) * 100);

                        tb_ElbowDistance.Text = distanceBetweenElbows.ToString();


                        if ((distanceBetweenElbows >= 40 && distanceBetweenElbows <= 60) && (distance >= 40 && distance <= 60))
                        {
                            tb_Message.Text = "Hello Arvind";
                        }
                        else
                        {
                            tb_Message.Text = "Not identified";
                        }

                    }
                }
                else if (bodyCount == 0)
                {
                    

                    sensor.ColorStream.Disable();
                    sensor.DepthStream.Disable();
                    tb_bodyCounter.Text = "No person detected";
                    tb_information.Text = string.Empty;
                    tb_HandsDistance.Text = string.Empty;
                    depthImageControl.Visibility = System.Windows.Visibility.Hidden;
                    colorImageControl.Visibility = System.Windows.Visibility.Hidden;
                    skeletonCanvas.Visibility = System.Windows.Visibility.Hidden;

                }

                else if (bodyCount > 1)
                {
                   

                    tb_bodyCounter.Text = bodyCount.ToString() + " persons detected.";
                    sensor.ColorStream.Disable();
                    sensor.DepthStream.Disable();
                    tb_information.Text = string.Empty;
                    depthImageControl.Visibility = System.Windows.Visibility.Hidden;
                    colorImageControl.Visibility = System.Windows.Visibility.Hidden;
                    skeletonCanvas.Visibility = System.Windows.Visibility.Hidden;
                }

            }
        }



        private void MapJointsWithUIElements(Skeleton firstSkeleton)
        {
            // 1 mapping the left hand
            Point mappedLeftHand = ScalePosition(firstSkeleton.Joints[JointType.HandLeft].Position);
            Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(leftHandPointer, mappedLeftHand.Y);


            // 2 mapping the right hand
            Point mappedRigthHand = ScalePosition(firstSkeleton.Joints[JointType.HandRight].Position);
            Canvas.SetLeft(rightHandPointer, mappedRigthHand.X);
            Canvas.SetTop(rightHandPointer, mappedRigthHand.Y);

            // 3 mapping of head
            Point mappedHead = ScalePosition(firstSkeleton.Joints[JointType.Head].Position);
            Canvas.SetLeft(headPointer, mappedHead.X);
            Canvas.SetTop(headPointer, mappedHead.Y);

            // 4,5 mapping for shoulders
            Point mappedLeftShoulder = ScalePosition(firstSkeleton.Joints[JointType.ShoulderLeft].Position);
            Canvas.SetLeft(leftShoulderPointer, mappedLeftShoulder.X);
            Canvas.SetTop(leftShoulderPointer, mappedLeftShoulder.Y);

            Point mappedRightShoulder = ScalePosition(firstSkeleton.Joints[JointType.ShoulderRight].Position);
            Canvas.SetLeft(rightShoulderPointer, mappedRightShoulder.X);
            Canvas.SetTop(rightShoulderPointer, mappedRightShoulder.Y);

            // 6 mapping for shoulder center
            Point mappedShoulderCenter = ScalePosition(firstSkeleton.Joints[JointType.ShoulderCenter].Position);
            Canvas.SetLeft(shoulderCenterPointer, mappedShoulderCenter.X);
            Canvas.SetTop(shoulderCenterPointer, mappedShoulderCenter.Y);

            // 7, 8 mapping for elbows
            Point mappedLeftElbow = ScalePosition(firstSkeleton.Joints[JointType.ElbowLeft].Position);
            Canvas.SetLeft(leftElbowPointer, mappedLeftElbow.X);
            Canvas.SetTop(leftElbowPointer, mappedLeftElbow.Y);

            Point mappedRightElbow = ScalePosition(firstSkeleton.Joints[JointType.ElbowRight].Position);
            Canvas.SetLeft(rightElbowPointer, mappedRightElbow.X);
            Canvas.SetTop(rightElbowPointer, mappedRightElbow.Y);

            // 9,10,11 mapping for hips
            Point mappedLeftHipJoint = ScalePosition(firstSkeleton.Joints[JointType.HipLeft].Position);
            Canvas.SetLeft(leftHipJointPointer, mappedLeftHipJoint.X);
            Canvas.SetTop(leftHipJointPointer, mappedLeftHipJoint.Y);

            Point mappedRightHipJoint = ScalePosition(firstSkeleton.Joints[JointType.HipRight].Position);
            Canvas.SetLeft(rightHipJointPointer, mappedRightHipJoint.X);
            Canvas.SetTop(rightHipJointPointer, mappedRightHipJoint.Y);

            Point mappedCenterHipJoint = ScalePosition(firstSkeleton.Joints[JointType.HipCenter].Position);
            Canvas.SetLeft(centerHipJointPointer, mappedCenterHipJoint.X);
            Canvas.SetTop(centerHipJointPointer, mappedCenterHipJoint.Y);

            // 12,13 mapping for whrists
            Point mappedLeftWhrist = ScalePosition(firstSkeleton.Joints[JointType.WristLeft].Position);
            Canvas.SetLeft(leftWristPointer, mappedLeftWhrist.X);
            Canvas.SetTop(leftWristPointer, mappedLeftWhrist.Y);

            Point mappedRightWhrist = ScalePosition(firstSkeleton.Joints[JointType.WristRight].Position);
            Canvas.SetLeft(rightWristPointer, mappedRightWhrist.X);
            Canvas.SetTop(rightWristPointer, mappedRightWhrist.Y);

            // 14,15 mapping for knee
            Point mappedLeftKnee = ScalePosition(firstSkeleton.Joints[JointType.KneeLeft].Position);
            Canvas.SetLeft(leftKneePointer, mappedLeftKnee.X);
            Canvas.SetTop(leftKneePointer, mappedLeftKnee.Y);

            Point mappedRightKnee = ScalePosition(firstSkeleton.Joints[JointType.KneeRight].Position);
            Canvas.SetLeft(rightKneePointer, mappedRightKnee.X);
            Canvas.SetTop(rightKneePointer, mappedRightKnee.Y);

            // 16,17 mapping for ankles
            Point mappedLeftAnkle = ScalePosition(firstSkeleton.Joints[JointType.AnkleLeft].Position);
            Canvas.SetLeft(leftAnklePointer, mappedLeftAnkle.X);
            Canvas.SetTop(leftAnklePointer, mappedLeftAnkle.Y);

            Point mappedRightAnkle = ScalePosition(firstSkeleton.Joints[JointType.AnkleRight].Position);
            Canvas.SetLeft(rightAnklePointer, mappedRightAnkle.X);
            Canvas.SetTop(rightAnklePointer, mappedRightAnkle.Y);

            //18 ,19 mapping for foot
            Point mappedLeftFoot = ScalePosition(firstSkeleton.Joints[JointType.FootLeft].Position);
            Canvas.SetLeft(leftfootPointer, mappedLeftFoot.X);
            Canvas.SetTop(leftfootPointer, mappedLeftFoot.Y);

            Point mappedRightFoot = ScalePosition(firstSkeleton.Joints[JointType.FootRight].Position);
            Canvas.SetLeft(rightfootPointer, mappedRightFoot.X);
            Canvas.SetTop(rightfootPointer, mappedRightFoot.Y);

            // 20 mapping for spine
            Point mappedSpine = ScalePosition(firstSkeleton.Joints[JointType.Spine].Position);
            Canvas.SetLeft(spinePointer, mappedSpine.X);
            Canvas.SetTop(spinePointer, mappedSpine.Y);


            //connecting the joints via bones.
            //drawBone(firstSkeleton.Joints[JointType.HipCenter], firstSkeleton.Joints[JointType.HipRight]);
            //drawBone(firstSkeleton.Joints[JointType.HipRight], firstSkeleton.Joints[JointType.KneeRight]);
            //drawBone( firstSkeleton.Joints[JointType.KneeRight], firstSkeleton.Joints[JointType.AnkleRight]);
            //drawBone( firstSkeleton.Joints[JointType.AnkleRight],firstSkeleton.Joints[JointType.FootRight]);

            //drawBone(firstSkeleton.Joints[JointType.HipCenter], firstSkeleton.Joints[JointType.HipLeft]);
            //drawBone(firstSkeleton.Joints[JointType.HipLeft], firstSkeleton.Joints[JointType.KneeLeft]);
            //drawBone(firstSkeleton.Joints[JointType.KneeLeft], firstSkeleton.Joints[JointType.AnkleLeft]);
            //drawBone(firstSkeleton.Joints[JointType.AnkleLeft], firstSkeleton.Joints[JointType.FootLeft]);


            //drawBone(firstSkeleton.Joints[JointType.HipCenter],firstSkeleton.Joints[JointType.Spine]);
            //drawBone(firstSkeleton.Joints[JointType.Spine], firstSkeleton.Joints[JointType.ShoulderCenter]);

            //drawBone(firstSkeleton.Joints[JointType.ShoulderCenter], firstSkeleton.Joints[JointType.ShoulderRight]);
            //drawBone(firstSkeleton.Joints[JointType.ShoulderCenter], firstSkeleton.Joints[JointType.Head]);
            //drawBone(firstSkeleton.Joints[JointType.ShoulderCenter], firstSkeleton.Joints[JointType.ShoulderLeft]);

            //drawBone(firstSkeleton.Joints[JointType.ShoulderRight], firstSkeleton.Joints[JointType.ElbowRight]);
            //drawBone(firstSkeleton.Joints[JointType.ElbowRight], firstSkeleton.Joints[JointType.WristRight]);
            //drawBone(firstSkeleton.Joints[JointType.WristRight], firstSkeleton.Joints[JointType.HandRight]);

            //drawBone(firstSkeleton.Joints[JointType.ShoulderLeft], firstSkeleton.Joints[JointType.ElbowLeft]);
            //drawBone(firstSkeleton.Joints[JointType.ElbowLeft], firstSkeleton.Joints[JointType.WristLeft]);
            //drawBone(firstSkeleton.Joints[JointType.WristLeft], firstSkeleton.Joints[JointType.HandLeft]);

            
        }

        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            DepthImagePoint depthPoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            //if (IsHead)
            //{
            //    tb_DeviceDistance.Text = depthPoint.Depth.ToString();
            //}

            return new Point(depthPoint.X, depthPoint.Y);
        }

        private void KinectWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //do something    
            
        
        }

        

        private float GetDistance(Joint firstJoint, Joint secondJoint)
        {
            float distanceX = firstJoint.Position.X - secondJoint.Position.X;
            float distanceY = firstJoint.Position.Y - secondJoint.Position.Y;
            float distanceZ = firstJoint.Position.Z - secondJoint.Position.Z;
            return (float)Math.Sqrt(Math.Pow(distanceX, 2) + Math.Pow(distanceY, 2) + Math.Pow(distanceZ, 2));
        }

        void drawBone(Joint firstJoint, Joint secondJoint)
        {
            Line skeletonBone = new Line();
            skeletonBone.Stroke = Brushes.Black;
            skeletonBone.StrokeThickness = 3; 
            Point joint1 = this.ScalePosition(firstJoint.Position);
            skeletonBone.X1 = joint1.X;
            skeletonBone.Y1 = joint1.Y;

            Point joint2 = this.ScalePosition(secondJoint.Position);
            skeletonBone.X2 = joint2.X;
            skeletonBone.Y2 = joint2.Y;

            skeletonCanvas.Children.Add(skeletonBone);

            BonesIndexList.Insert(0,skeletonCanvas.Children.IndexOf(skeletonBone));

        }

        void removeBone()
        {
            skeletonCanvas.Children.RemoveAt(BonesIndexList.Count - 1);
        }
    }
}
