﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public enum RGBColorStream
{
    RedStream =0,
    GreenStream=1,
    BlueStream=2
}

namespace MappingImagesOnSkeleton
{
    public static class ColorStreamEffects
    {
        public static byte[] GrayScaleEffect(this byte[] PixelData, int BytesPerPixel)
        {
            for (int i = 0; i < PixelData.Length; i += BytesPerPixel)
            {
                var data = Math.Max(Math.Max(PixelData[i], PixelData[i + 1]), PixelData[i + 2]);
                PixelData[i] = data;//red
                PixelData[i + 1] = data;//green
                PixelData[i + 2] = data;//blue
            }
            return PixelData;
        }

        public static byte[] InvertColorEffect(this byte[] PixelData, int BytesPerPixel)
        {
            for (int i = 0; i < PixelData.Length; i += BytesPerPixel)
            {
                PixelData[i] = (byte)(~PixelData[i]);
                PixelData[i + 1] = (byte)(~PixelData[i + 1]);
                PixelData[i + 2] = (byte)(~PixelData[i + 2]);
            }
            return PixelData;
        }


        public static byte[] SepiaColorEffect(this byte[] PixelData, int BytesPerPixel)
        {
            for (int i = 0; i < PixelData.Length; i+= BytesPerPixel)
            {

                PixelData[i] =  (byte) Math.Min( ((PixelData[i] * 0.393) + (PixelData[i + 1] * .769) + (PixelData[i + 2] * .189)),255.0); 
                PixelData[i+1]= (byte) Math.Min( ((PixelData[i] * .349) + (PixelData[i + 1] * .686) + (PixelData[i + 2] * .168)),255.0);
                PixelData[i + 2] = (byte) Math.Min(((PixelData[i] * .272) + (PixelData[i + 1] * .534) + (PixelData[i + 2] * .131)),255.0);

                if ((PixelData[i + 2]) > 255)
                {
                    PixelData[i + 2] = 255;
                }

                if ((PixelData[i + 1]) > 255)
                {
                  PixelData[i + 1] = 255;
                }
                if ((PixelData[i + 0]) > 255)
                {
                    PixelData[i + 0] = 255;
                }
            }
            return PixelData;
        }

        public static byte[] RemoveStream(this byte[] PixelData,int BytesPerPixel,int ColorCode)
        {
            switch ((RGBColorStream)ColorCode)
            {
                case RGBColorStream.RedStream:
                    for (int i = 0; i < PixelData.Length; i += BytesPerPixel)
                    {
                        PixelData[i] = 0;
                    }
                    break;
                case RGBColorStream.GreenStream:
                    for (int i = 0; i < PixelData.Length; i += BytesPerPixel)
                    {
                        PixelData[i + 1] = 0;
                    }
                    break;
                case RGBColorStream.BlueStream:
                    for (int i = 0; i < PixelData.Length; i += BytesPerPixel)
                    {
                        PixelData[i + 2] = 0;
                    }
                    break;
                default:
                    //do nothing
                    break;
            }
            return PixelData;
        }


    }
}
