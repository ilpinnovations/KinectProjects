﻿using Microsoft.Kinect;
using System;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using System.IO;
using System.ComponentModel;
using System.Windows.Media.Imaging;

namespace MappingImagesOnSkeleton
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        enum Effects
        {
            GrayScale,
            InvertColor,
            Negative
        }

        #region KinectObjects
        KinectSensor sensor;
        Skeleton[] totalSkeletons = new Skeleton[6];
        public BitmapSource previousFrame { get; set; }
        public int previousFrameNumber { get; set; }
        public short CountDownCounter;
        DispatcherTimer timer;
        BackgroundWorker worker = new BackgroundWorker();
        private short CameraResolution;
        //DispatcherTimer animationTimer;
        bool IsGesturePerforming;

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            sensor = KinectSensor.KinectSensors.FirstOrDefault(sense => sense.Status == KinectStatus.Connected);
            if (sensor == null)
            {
                return;
            }

            if (sensor.SkeletonStream.IsEnabled == false)
            {
                sensor.SkeletonStream.Enable();
                //can not be used with event based frame fetching.
                //SkeletonFrame frame = this.sensor.SkeletonStream.OpenNextFrame(10);
                //sensor.ColorStream.CameraSettings.ExposureTime = 0.5;
                //sensor.ColorStream.CameraSettings.FrameInterval = 10;
                //sensor.ColorStream.CameraSettings.Hue = 10;

                sensor.SkeletonFrameReady += sensor_SkeletonFrameReady;
            }

            if (sensor.ColorStream.IsEnabled == false)
            {
                sensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
                //sensor.ColorStream.CameraSettings.BacklightCompensationMode = BacklightCompensationMode.CenterOnly;
                sensor.ColorFrameReady += sensor_ColorFrameReady;
            }

            sensor.Start();

            sensor.ElevationAngle = 5;

            //Getting the brightness data of camera.
            //Feature is not supported for kinect v1.8 device
            //slider_brightness.Maximum = sensor.ColorStream.CameraSettings.MaxBrightness;
            //slider_brightness.Minimum = sensor.ColorStream.CameraSettings.MinBrightness;

            worker.DoWork += worker_DoWork;        
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
        }

        

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {   
            if (sensor != null)
            {
                MessageBox.Show("Resolution Changed Successfully");
            }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            //Selecting the camera resolution using Combo Box
            if (sensor != null && sensor.ColorStream.IsEnabled == true)
            {
                //sensor.ColorStream.Disable();
                if (CameraResolution == 0)
                {
                    sensor.ColorStream.Enable(ColorImageFormat.RgbResolution640x480Fps30);
                }
                else if (CameraResolution == 1)
                {
                    sensor.ColorStream.Enable(ColorImageFormat.RgbResolution1280x960Fps12);
                }
            }            
        }



        void sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            try
            {
                using (var colorImageFrame = e.OpenColorImageFrame())
                {
                    int currentFrameNumber;
                    if (int.TryParse(colorImageFrame.FrameNumber.ToString(), out currentFrameNumber))
                    {
                        //var currentBitMapImage = colorImageFrame.ToBitmapSource();

                        #region GettingImageFrame Without Extension Methods
                        var pixelData = new byte[colorImageFrame.PixelDataLength];
                        colorImageFrame.CopyPixelDataTo(pixelData);
                        int stride = colorImageFrame.Width * colorImageFrame.BytesPerPixel;

                        if (chk_GrayScale.IsChecked == true)
                        {
                            chk_SepiaEffect.IsChecked = false;
                            pixelData.GrayScaleEffect(colorImageFrame.BytesPerPixel);
                        }
                        else if (chk_SepiaEffect.IsChecked == true)
                        {
                            pixelData.SepiaColorEffect(colorImageFrame.BytesPerPixel);
                            chk_GrayScale.IsChecked = false;
                        }
                        if (chk_InvertColor.IsChecked == true)
                        {
                            pixelData.InvertColorEffect(colorImageFrame.BytesPerPixel);
                        }
                        if (chk_RemoveRedPoint.IsChecked == true)
                        {
                            pixelData.RemoveStream(colorImageFrame.BytesPerPixel, 0);
                        }
                        if (chk_RemoveGreenPoint.IsChecked == true)
                        {
                            pixelData.RemoveStream(colorImageFrame.BytesPerPixel, 1);
                        }
                        if (chk_RemoveBluePoint.IsChecked == true)
                        {
                            pixelData.RemoveStream(colorImageFrame.BytesPerPixel, 2);
                        }



                        var currentBitMapImage = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height, 96, 96, PixelFormats.Bgr32, null, pixelData, stride);
                        this.CurrentFrameControl.Source = currentBitMapImage;


                        if (chk_MotionFrame.IsChecked == true)
                        {
                            //Motion Detector Images
                            currentBitMapImage = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height, 96, 96, PixelFormats.Bgr32, null, pixelData.InvertColorEffect(colorImageFrame.BytesPerPixel), stride);
                        }



                        //currentBitMapImage = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height, 96, 96, PixelFormats.Bgr32, null, pixelData.SepiaColorEffect(colorImageFrame.BytesPerPixel), stride);
                        #endregion

                        #region ShadowEffect
                        if (previousFrameNumber == 0)//Very First frame
                        {
                            previousFrameNumber = currentFrameNumber;
                            previousFrame = currentBitMapImage;
                        }
                        else if (currentFrameNumber - previousFrameNumber >= 1)
                        {
                            //txt_currentFrameNumber.Text = "Previous Frame Number :" + previousFrameNumber + " Current Frame Number :" + currentFrameNumber;
                            this.PreviousFrameControl.Source = previousFrame;

                            previousFrame = currentBitMapImage;
                            previousFrameNumber = colorImageFrame.FrameNumber;

                        }
                        #endregion

                    }
                }
            }
            catch (Exception )
            {
                //Handle the exception manually.

            }
        }

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }
                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();
                if (firstSkeleton == null)
                {
                    return;
                }
                SkeletonMapper(firstSkeleton);
            }
        }

        //Mapping the skeleton joints to UI Elements
        public void MapJointsToUIElement(SkeletonPoint Point)
        {

        }

        private void SkeletonMapper(Skeleton firstSkeleton)
        {

            if (firstSkeleton.Joints[JointType.Head].TrackingState == JointTrackingState.Tracked)
            {
                MapJointsToUIElement(firstSkeleton.Joints[JointType.Head].Position);
            }

            if (firstSkeleton.Joints[JointType.HandRight].Position.Y > firstSkeleton.Joints[JointType.Head].Position.Y && IsGesturePerforming == false)
            {
                IsGesturePerforming = true;
                StartTimer();
            }
        }

        //private void MapImagesToSkeleton(Skeleton trackedSkeleton)
        //{
        //    var leftShoulder = trackedSkeleton.Joints[JointType.ShoulderLeft];
        //    var rightShoulder = trackedSkeleton.Joints[JointType.ShoulderRight];

        //    Joint ScaledLeftShoulder = leftShoulder.ScaleTo(
        //        640,
        //        480,
        //        1.0f,
        //        1.0f);

        //    Joint ScaledRightShoulder = rightShoulder.ScaleTo(
        //    (int)System.Windows.SystemParameters.PrimaryScreenWidth,
        //    (int)System.Windows.SystemParameters.PrimaryScreenHeight,
        //    0.6f,
        //    0.4f);

        //    Canvas.SetLeft(mapBorder, ScaledLeftShoulder.Position.X);
        //    Canvas.SetTop(mapBorder, ScaledLeftShoulder.Position.Y);
        //}

        private void Window_Closed_1(object sender, EventArgs e)
        {
            if (sensor != null)
            {
                sensor.Stop();
            }
        }
        private void btn_SaveImage_Click_1(object sender, RoutedEventArgs e)
        {
            if (chk_InstantImage.IsChecked == true)
            {
                SaveImage(CurrentFrameControl);
            }
            else
            {
                StartTimer();
            }
        }
        private void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = new TimeSpan(0, 0, 1);
            CountDownCounter = 3;
            timer.Start();
            timer.Tick += timer_Tick;
        }
        void timer_Tick(object sender, EventArgs e)
        {
            tb_Counter.Text = CountDownCounter.ToString();
            CountDownCounter--;
            if (CountDownCounter == -1)
            {
                SaveImage(CurrentFrameControl);
                //apply the animation here.
                timer.Stop();
                CountDownCounter = 0;
                tb_Counter.Text = "Captured";
                IsGesturePerforming = false;
            }
        }
        private void SaveImage(System.Windows.Controls.Image imgControl)
        {
            //Change the path before saving the image
            using (FileStream fileStream = new FileStream(string.Format(@"c:\users\arvindtheadmin\desktop\{0}.jpg", Guid.NewGuid().ToString()), 
                FileMode.Create))
            {
                BitmapSource imgSource = (BitmapSource)imgControl.Source;
                JpegBitmapEncoder jpegEncoder = new JpegBitmapEncoder();
                jpegEncoder.Frames.Add(BitmapFrame.Create(imgSource));
                jpegEncoder.Save(fileStream);
                img_LastImage.Source = imgSource;
                fileStream.Close();
            }
        }
        private void cb_cameraResolution_SelectionChanged_1(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            CameraResolution = Convert.ToInt16(cb_cameraResolution.SelectedIndex);
            worker.RunWorkerAsync();
        }

        //Brightness change is not supported in kinect v1.8 device
        //private void slider_brightness_ValueChanged_1(object sender, RoutedPropertyChangedEventArgs<double> e)
        //{
        //    sensor.ColorStream.CameraSettings.Brightness = slider_brightness.Value;
        //}
    }
}
