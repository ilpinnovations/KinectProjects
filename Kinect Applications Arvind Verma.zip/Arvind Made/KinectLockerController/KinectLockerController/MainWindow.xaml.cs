﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using Microsoft.Kinect;
using System.Net.Http;

namespace KinectLockerController
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public delegate void OperationBinder(bool IsOpened);

        #region KinectObjects
        KinectSensor sensor;
        Skeleton[] totalSkeleton = new Skeleton[6];
        HttpClient client = new HttpClient();
        bool IsOpen;
        const string NetworkURL = "http://192.168.43.2/kinect.php";
        OperationBinder binder;
        short NumberofPersons;
        #endregion


        public MainWindow()
        {
            InitializeComponent();

            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    sensor.SkeletonStream.Enable(new TransformSmoothParameters() { Smoothing = 0.5f, Correction = 0.0f,
                        MaxDeviationRadius = 0.9f });
                    sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
                }
                sensor.Start(); 
            }
            catch (Exception exp)
            {

                MessageBox.Show("Kinect Connectivity Error: " +exp.Message);
            }
                     
        }

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }
                skeletonFrame.CopySkeletonDataTo(totalSkeleton);

                var firstSkeleton = totalSkeleton.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();
                NumberofPersons = Convert.ToInt16(totalSkeleton.Count(skeleton_count => skeleton_count.TrackingState == SkeletonTrackingState.Tracked));


                if (NumberofPersons == 0)
                {
                    sb_info.Items.Clear();
                    sb_info.Background = Brushes.Gray;
                    sb_info.Items.Add(NumberofPersons + " Person(s) Detected");
                    if (sensor.ColorStream.IsEnabled == true)
                    { 
                        sensor.ColorStream.Disable();
                        kinectImageControl.Visibility = Visibility.Hidden;
                        kinectImageControl.Source = null;
                    }
                }
                else if (NumberofPersons == 1)
                {
                    sb_info.Items.Clear();
                    sb_info.Items.Add(NumberofPersons + " Person(s) Detected");
                    sb_info.Background = Brushes.Green;
                    MapJointsToUIElement(firstSkeleton);
                    kinectImageControl.Visibility = Visibility.Visible;
                    GetColorImage(firstSkeleton);
                }
                else if (NumberofPersons == 2)
                {
                    sb_info.Items.Clear();
                    sb_info.Background = Brushes.Red;
                    sb_info.Items.Add(NumberofPersons + " Person(s) Detected");
                    if (sensor.ColorStream.IsEnabled == true)
                    {
                        sensor.ColorStream.Disable();
                        kinectImageControl.Visibility = Visibility.Hidden;
                        kinectImageControl.Source = null;
                    }
                }

                if (firstSkeleton == null)
                {
                    return;
                }
            }
        }

        private void GetColorImage(Skeleton firstSkeleton)
        {
            //try to connect with color strem.
            if (sensor.ColorStream.IsEnabled == false)
            {
                sensor.ColorStream.Enable();
                sensor.ColorFrameReady += new EventHandler<ColorImageFrameReadyEventArgs>(sensor_ColorFrameReady);
            }
        }

        void sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {
            using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
            {
                if (colorImageFrame == null)
                {
                    return;
                }
                
                var pixelData = new byte[colorImageFrame.PixelDataLength];
                colorImageFrame.CopyPixelDataTo(pixelData);

                int stride = colorImageFrame.Width * colorImageFrame.BytesPerPixel;
                
                kinectImageControl.Source = BitmapSource.Create(colorImageFrame.Width, colorImageFrame.Height,
                       96, 96, PixelFormats.Bgr32, null, pixelData, stride);
            }
        }

        private void OpenLocker(bool IsOpen)
        {
            try
            {
                if (IsOpen == true)
                {
                    //locker is already opened.
                }
                else
                {
                    Dictionary<string, string> postData = new Dictionary<string, string>();
                    postData["tag"] = "KinectOpen";
                    FormUrlEncodedContent formUrlContent = new FormUrlEncodedContent(postData);
                    txt_message.Text = "Connecting to server...";
                    var response = client.PostAsync(NetworkURL, formUrlContent).Result;
                    string responseString = response.Content.ReadAsStringAsync().Result;

                    //txt_message.Text += responseString;
                   // txt_message.Text += "locker open message sent";

                    //You need to change the path image. You can also C# resource setting file to get ride to changing the path.
                    this.img_lockStatus.Source = new BitmapImage( new Uri(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\KinectLockerController\KinectLockerController\Images\lockOpen.PNG"));
                    IsOpen = true;
                }
            }
            catch (Exception exp)
            {
                //txt_message.Text = "Unable to connect." + " Technical Error :" + exp.Message;
            }
        }

        private void CloseLocker(bool IsOpen)
        {

            try
            {
                if (IsOpen == true)
                {
                    Dictionary<string, string> postData = new Dictionary<string, string>();
                    postData["tag"] = "KinectClose";
                    FormUrlEncodedContent formUrlContent = new FormUrlEncodedContent(postData);
                    txt_message.Text = "Connecting to server...";
                    var response = client.PostAsync(NetworkURL, formUrlContent).Result;
                    string responseString = response.Content.ReadAsStringAsync().Result;
                    //txt_message.Text += responseString;
                    //txt_message.Text += "Locker close Message Sent.";
                    //You need to change the path image. You can also C# resource setting file to get ride to changing the path.
                    img_lockStatus.Source = new BitmapImage(new Uri(@"F:\PROGRAMMING IS EVERYTHING\MVA Microsoft Kinect Jumpstart\Arvind Made\KinectLockerController\KinectLockerController\Images\lockClose.PNG"));
                    IsOpen = false;
                }
                else
                {
                    //locker is already closed.
                }
            }
            catch (Exception exp)
            {

               // txt_message.Text = "Unable to connect." + " Technical Error :" + exp.Message;
            }
        }


        private void MapJointsToUIElement(Skeleton firstSkeleton)
        {
            // IsOpen = true;
            Point mappedRightHand = ScalePosition(firstSkeleton.Joints[JointType.HandRight].Position);
            Canvas.SetLeft(rightHandPointer, mappedRightHand.X);
            Canvas.SetTop(rightHandPointer, mappedRightHand.Y);

            Point mappedLeftHand = ScalePosition(firstSkeleton.Joints[JointType.HandLeft].Position);
            Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(leftHandPointer, mappedLeftHand.Y);

            //creating the custom gesture for opening the locker.
            //Checking for the left hand position
            if ((firstSkeleton.Joints[JointType.HandLeft].Position.Y > firstSkeleton.Joints[JointType.ElbowLeft].Position.Y) && (firstSkeleton.Joints[JointType.HandRight].Position.Y > firstSkeleton.Joints[JointType.ElbowRight].Position.Y))
            {
                var zRightHand = firstSkeleton.Joints[JointType.HandRight].Position.Z * 100;
                var zHead = firstSkeleton.Joints[JointType.Head].Position.Z * 100;
                //var zElbowRight = firstSkeleton.Joints[JointType.ElbowRight].Position.Z * 100;
                var zSpine = firstSkeleton.Joints[JointType.Spine].Position.Z * 100;

                var difference = zSpine - zRightHand;


                //txt_message.Text = difference.ToString();

                if (difference >= 15 && difference <= 20)
                {
                    if (IsOpen == false)
                    {
                        //MessageBox.Show("Locker Opened !");
                        //locker is closed.     
                        binder += new OperationBinder(OpenLocker);
                        binder -= new OperationBinder(CloseLocker);
                        binder.Invoke(IsOpen);
                        IsOpen = true;
                    }
                }

                else if (difference >= 45 && difference <= 50)
                {
                    if (IsOpen == true)
                    {
                        //MessageBox.Show("Locker Closed !");
                        binder += new OperationBinder(CloseLocker);
                        binder -= new OperationBinder(OpenLocker);
                        binder.Invoke(IsOpen);
                        IsOpen = false;
                    }
                }
            }
        }

        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            return new Point() { X = depthImagePoint.X, Y = depthImagePoint.Y };
        }
    }
}
