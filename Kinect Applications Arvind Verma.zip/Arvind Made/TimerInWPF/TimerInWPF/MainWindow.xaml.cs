﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;

namespace TimerInWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        DispatcherTimer timer = new DispatcherTimer();
        short tick;
        public MainWindow()
        {
            InitializeComponent();
            timer.Interval = new TimeSpan(0, 0, 1);
            timer.Tick += new EventHandler(timer_Tick);
        }

        private void btn_Start_Click(object sender, RoutedEventArgs e)
        {

            timer.Start();
           
        }

        void timer_Tick(object sender, EventArgs e)
        { 
            ++tick;
            tb_Counter.Text = tick.ToString();
            
        }

        private void btn_Stop_Click(object sender, RoutedEventArgs e)
        {
            timer.Stop();
        }

        private void btn_Pause_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
