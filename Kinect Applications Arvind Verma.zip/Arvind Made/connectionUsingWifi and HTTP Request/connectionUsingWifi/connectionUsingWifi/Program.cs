﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Http;

namespace connectionUsingWifi
{
    class Program
    {
        static void Main(string[] args)
        {
            const string URL = "http://192.168.43.254/index.php";
            HttpClient client = new HttpClient();
            Dictionary<string, string> postData = new Dictionary<string, string>();
            postData["tag"] = "Kinect";  

            FormUrlEncodedContent formUrlContent = new FormUrlEncodedContent(postData);

            Console.WriteLine("Requesting to server");

            var response = client.PostAsync(URL, formUrlContent).Result;

            string responseString = response.Content.ReadAsStringAsync().Result;

            Console.WriteLine("Response from server: " + responseString);
            Console.ReadKey();
        }
    }
}
