﻿namespace ControllingCursorsUsingKinect_WinFormsApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_control1 = new System.Windows.Forms.Button();
            this.btn_control2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_stopTracking = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btn_control1
            // 
            this.btn_control1.Font = new System.Drawing.Font("Segoe WP", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_control1.Location = new System.Drawing.Point(291, 176);
            this.btn_control1.Name = "btn_control1";
            this.btn_control1.Size = new System.Drawing.Size(216, 166);
            this.btn_control1.TabIndex = 0;
            this.btn_control1.Text = "Control 1";
            this.btn_control1.UseVisualStyleBackColor = true;
            this.btn_control1.Click += new System.EventHandler(this.btn_control1_Click);
            // 
            // btn_control2
            // 
            this.btn_control2.Font = new System.Drawing.Font("Segoe WP", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_control2.Location = new System.Drawing.Point(556, 176);
            this.btn_control2.Name = "btn_control2";
            this.btn_control2.Size = new System.Drawing.Size(207, 166);
            this.btn_control2.TabIndex = 1;
            this.btn_control2.Text = "Control 2";
            this.btn_control2.UseVisualStyleBackColor = true;
            this.btn_control2.Click += new System.EventHandler(this.btn_control2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe WP", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 37);
            this.label1.TabIndex = 2;
            // 
            // btn_stopTracking
            // 
            this.btn_stopTracking.Font = new System.Drawing.Font("Segoe WP", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stopTracking.Location = new System.Drawing.Point(26, 176);
            this.btn_stopTracking.Name = "btn_stopTracking";
            this.btn_stopTracking.Size = new System.Drawing.Size(216, 166);
            this.btn_stopTracking.TabIndex = 3;
            this.btn_stopTracking.Text = "Stop Tracking";
            this.btn_stopTracking.UseVisualStyleBackColor = true;
            this.btn_stopTracking.Click += new System.EventHandler(this.btn_stopTracking_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(797, 390);
            this.Controls.Add(this.btn_stopTracking);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_control2);
            this.Controls.Add(this.btn_control1);
            this.Font = new System.Drawing.Font("Segoe WP", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Kinect Cursor Simulator";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion



        private System.Windows.Forms.Button btn_control1;
        private System.Windows.Forms.Button btn_control2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_stopTracking;

    }
}

