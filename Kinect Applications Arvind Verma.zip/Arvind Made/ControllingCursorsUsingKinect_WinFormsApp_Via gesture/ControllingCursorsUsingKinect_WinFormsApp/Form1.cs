﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Coding4Fun.Kinect.WinForm;
using System.Windows;
using WindowsInput;
using Microsoft.Kinect;
using KinectMouseController;

namespace ControllingCursorsUsingKinect_WinFormsApp
{
    public partial class Form1 : Form
    {

        #region KinectSensor and Data Holders
        private KinectSensor sensor;
        private Skeleton[] totalSkeletons = new Skeleton[6];
        private const float SkeletonMaxX = 0.30f;
        private const float SkeletonMaxY = 0.20f;
        bool IsLeftClicked;
        bool IsRightClicked;
        MouseSimulator mouse = new MouseSimulator();
       
        #endregion

        public Form1()
        {
            InitializeComponent();

            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor == null)
                {
                    return;
                }

                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    #region Standard Smooth Parameters
                    //TransformSmoothParameters parameters = new TransformSmoothParameters();
                    //parameters.Smoothing = 0.7f;
                    //parameters.Correction = 0.3f;
                    //parameters.Prediction = 0.4f;
                    //parameters.JitterRadius = 1.0f;
                    //parameters.MaxDeviationRadius = 0.5f;
                    #endregion

                    TransformSmoothParameters parameters = new TransformSmoothParameters();
                    parameters.Smoothing = 0.7f;
                    parameters.Correction = 0.3f;
                    parameters.Prediction = 0.4f;
                    parameters.JitterRadius = 0.1f;
                    // parameters.MaxDeviationRadius = 0.5f;


                    //Getting data from kinect
                    sensor.SkeletonStream.Enable(parameters);
                    //sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;

                    sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
                }
                sensor.Start();
                //sensor.ElevationAngle = 0;
            }
            catch (Exception  exp)
            {
                MessageBox.Show("Kinect Connectivity Issue :"+exp.Message);
            }
           
           

        }



        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);
                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }


        private void MapJointsToUIElement(Skeleton skeleton)
        {

            Joint rightHand = skeleton.Joints[JointType.HandRight];
            Joint leftHand = skeleton.Joints[JointType.HandLeft];

            Joint scaledRight = rightHand.ScaleTo(1366, 768, SkeletonMaxX, SkeletonMaxY);
            Joint scaledLeft = leftHand.ScaleTo(1366, 768, SkeletonMaxX, SkeletonMaxY);



            //controlling the cursor using right hand.
            if (skeleton.Joints[JointType.HandRight].Position.Y > skeleton.Joints[JointType.ElbowRight].Position.Y)
            {

                PerformActions(new Point() { X = Convert.ToInt32( scaledRight.Position.X), Y = Convert.ToInt32( scaledRight.Position.Y) }, new Point() { X =  Convert.ToInt32( scaledLeft.Position.X), Y = Convert.ToInt32( scaledLeft.Position.Y) }, skeleton);


                //Canvas.SetLeft(rightHandPointer, scaledRight.Position.X);
                //Canvas.SetTop(rightHandPointer, scaledRight.Position.Y);

                //implement the mouse controller code here.



                //KinectMouseMethods.SendMouseInput(Convert.ToInt32(scaledRight.Position.X), Convert.ToInt32(scaledRight.Position.Y), (int)SystemParameters.PrimaryScreenWidth, (int) SystemParameters.PrimaryScreenHeight, false);    


            }

            //controlling the cursor using left hand.
            if (skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
            {
                PerformActions(new Point() { X = Convert.ToInt32( scaledRight.Position.X), Y =  Convert.ToInt32( scaledRight.Position.Y) }, new Point() { X =  Convert.ToInt32( scaledLeft.Position.X), Y = Convert.ToInt32( scaledLeft.Position.Y) }, skeleton);
                //Canvas.SetLeft(rightHandPointer, scaledLeft.Position.X);
                //Canvas.SetTop(rightHandPointer, scaledLeft.Position.Y);
            }



           


        }

        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            //return PointToScreen(new Point(depthImagePoint.X, depthImagePoint.Y));
            return new Point((depthImagePoint.X), (depthImagePoint.Y));
        }


        private void PerformActions(Point mappedRightHandPoint, Point mappedLeftHandPoint, Skeleton trackedSkeleton)
        {
            #region simulating the mouse co-ordinates using C#

            var zHead = (trackedSkeleton.Joints[JointType.Head].Position.Z * 100);
            //Implementing the right hand interaction model for right hand pointer.
            if (trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.ElbowRight].Position.Y && trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.HandLeft].Position.Y)
            {
                var zRightHand = (trackedSkeleton.Joints[JointType.HandRight].Position.Z * 100);

                Cursor.Position = new Point(mappedRightHandPoint.X, mappedRightHandPoint.Y);

                //KinectMouseController.KinectMouseMethods.SendMouseInput(mappedRightHandPoint.X, mappedRightHandPoint.Y,

                //    1366, 768, false
                //    );

                var DifferenceBetweenRightHandandHead = zHead - zRightHand;

                //tb_difference.Text = DifferenceBetweenRightHandandHead.ToString();

                if (DifferenceBetweenRightHandandHead > 45 && IsRightClicked == false)
                {
                    //KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedRightHandPoint.X), Convert.ToInt32(mappedRightHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, true);

                  
                    mouse.SimulateMouseRightClick();
                    IsRightClicked = true;
                }
                else if (DifferenceBetweenRightHandandHead <= 38 && DifferenceBetweenRightHandandHead > 10)
                {
                    IsRightClicked = false;
                }
            }


            //Implementing the left hand interaction model for left hand model.
            if (trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.ElbowLeft].Position.Y && trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.HandRight].Position.Y)
            {
                var zLeftHand = (trackedSkeleton.Joints[JointType.HandLeft].Position.Z * 100);

                //KinectMouseController.KinectMouseMethods.SendMouseInput(mappedLeftHandPoint.X, mappedLeftHandPoint.Y,

                //   1366, 768, false
                //   );
               // KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, false);
               Cursor.Position = new Point(mappedLeftHandPoint.X, mappedLeftHandPoint.Y);
                var DifferenceBetweenLeftHandandHead = zHead - zLeftHand;
                if (DifferenceBetweenLeftHandandHead > 45 && IsLeftClicked == false)
                {
                   // KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, true);
                    mouse.SimulateMouseLeftClick();
                    IsLeftClicked = true;
                }
                else if (DifferenceBetweenLeftHandandHead <= 38 && DifferenceBetweenLeftHandandHead > 10)
                {
                    IsLeftClicked = false;
                }
            }

            #endregion

            //Not able to handle the events.
            //Cursor.Position = new Point(mappedRightHandPoint.X, mappedRightHandPoint.Y);//Implementing the cursor using winforms managed api.

            //mouse.SimulateMouseClick();

            //Driver Approach
            //mouse.SimulateMouseMove(mappedRightHandPoint.X, mappedRightHandPoint.Y);
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //stopping the sensor.
            if (sensor != null)
            {
                sensor.Stop();                
            }
        }

        private void btn_control1_Click(object sender, EventArgs e)
        {
            label1.Text = "Control 1 is clicked using Kinect Cursor !";
        }

        private void btn_control2_Click(object sender, EventArgs e)
        {
            label1.Text = "Control 2 is clicked using Kinect Cursor !";
        }

        private void btn_stopTracking_Click(object sender, EventArgs e)
        {
            if (sensor != null && sensor.SkeletonStream.IsEnabled == true && btn_stopTracking.Text == "Stop Tracking")
            {
                sensor.SkeletonStream.Disable();
                btn_stopTracking.Text = "Start Tracking";
            }
            else if (sensor !=null && sensor.SkeletonStream.IsEnabled == false && btn_stopTracking.Text =="Start Tracking")
            {
                sensor.SkeletonStream.Enable();
                btn_stopTracking.Text = "Stop Tracking";
            }
        }
    }
}
