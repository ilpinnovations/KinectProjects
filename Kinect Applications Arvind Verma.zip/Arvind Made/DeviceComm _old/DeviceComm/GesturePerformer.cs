﻿using Microsoft.Kinect;
using System;

namespace DeviceComm
{
    class GesturePerformer
    {
        #region IsGesturePerformed_Collection;
        static bool IsMaxHandDistanceGesturePerformed = false;
        #endregion

        public static bool MaxHandDistanceGesture(Skeleton trackedSkeleton)
        {
            if (trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.ElbowLeft].Position.Y && trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.ElbowRight].Position.Y)
            {
                if (Math.Round(trackedSkeleton.Joints[JointType.HandRight].GetDistance(trackedSkeleton.Joints[JointType.HandRight])) > 110 && IsMaxHandDistanceGesturePerformed == false)
                {
                    IsMaxHandDistanceGesturePerformed = true;
                    return true;
                }
                
            }
            else if (trackedSkeleton.Joints[JointType.HandLeft].Position.Y < trackedSkeleton.Joints[JointType.ElbowLeft].Position.Y && trackedSkeleton.Joints[JointType.HandRight].Position.Y < trackedSkeleton.Joints[JointType.ElbowRight].Position.Y)
            {
                IsMaxHandDistanceGesturePerformed = false;
                return false;
            }

            return false;
        }
    }
}
