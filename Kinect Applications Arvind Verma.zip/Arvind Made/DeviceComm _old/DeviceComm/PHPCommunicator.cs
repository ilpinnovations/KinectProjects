﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DeviceComm
{
    class PHPCommunicator
    {
       // string URL = "http://192.168.1.103/startsong.php";

        public static void DataSender(string key, string value,string URL)
        {
            var webclient = new WebClient();
            webclient.DownloadStringAsync(new Uri(URL + "?" + key + "=" + value));
        }
    }
}
