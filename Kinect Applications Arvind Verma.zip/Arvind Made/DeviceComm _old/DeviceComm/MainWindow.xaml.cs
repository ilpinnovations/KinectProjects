﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Kinect;
using Microsoft.Kinect.Toolkit;
using Microsoft.Kinect.Toolkit.Controls;
using System.ComponentModel;

namespace DeviceComm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        #region Kinect Data Holders
        //KinectSensor sensor;
        Skeleton[] totalSkeletons = new Skeleton[6];
        GesturePerformer performer = new GesturePerformer();
        public short NumberofPlayers { get; set; }
        bool isperformed_fullVolumeGesture = false;


        bool isPerformed_Device1 = false;
        bool isPerformed_Device2 = false;
        bool isPerformed_Device3 = false;
        bool isPerformed_Device4 = false;

        private readonly KinectSensorChooser sensorChooser;



        public double Volume { get; set; }

        string SongURL = "http://192.168.1.103/startsong.php";
        string VolumeURL = "http://192.168.1.103/setvolume.php";

        #endregion

        public MainWindow()
        {
            InitializeComponent();

            #region Boiler Plate for Kinect Interactions.
            this.sensorChooser = new KinectSensorChooser();
            this.sensorChooser.KinectChanged += SensorChooserOnKinectChanged;
            this.sensorChooserUi.KinectSensorChooser = this.sensorChooser;
            this.sensorChooser.Start();
            var regionSensorBinding = new Binding("Kinect") { Source = this.sensorChooser };
            BindingOperations.SetBinding(this.ActionRegion, KinectRegion.KinectSensorProperty, regionSensorBinding);
            #endregion

            //sending the intial volume
            Volume = 0.70;

            //#region Kinect BoilerPlate
            //try
            //{
            //    sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
            //    if (sensor == null)
            //    {
            //        return;
            //    }

            //    if (sensor.SkeletonStream.IsEnabled == false)
            //    {
            //        sensor.SkeletonStream.Enable();
            //        sensor.SkeletonFrameReady += Sensor_SkeletonFrameReady;
            //    }

            //    if (sensor.DepthStream.IsEnabled == false)
            //    {
            //        sensor.DepthStream.Enable();
            //        sensor.DepthFrameReady += Sensor_DepthFrameReady;
            //    }

            //    if (sensor.ColorStream.IsEnabled == false)
            //    {
            //        sensor.ColorStream.Enable();
            //        sensor.ColorFrameReady += Sensor_ColorFrameReady;
            //    }

            //    sensor.Start();
            //}
            //catch (Exception)
            //{

            //    //Handle the exception
            //}
            //#endregion


        }

        #region TheUltimateEvent
        private void SensorChooserOnKinectChanged(object sender, KinectChangedEventArgs args)
        {
            if (args.OldSensor != null)
            {
                try
                {
                    args.OldSensor.DepthStream.Range = DepthRange.Default;
                    args.OldSensor.SkeletonStream.EnableTrackingInNearRange = false;
                    args.OldSensor.DepthStream.Disable();
                    args.OldSensor.SkeletonStream.Disable();
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }

            if (args.NewSensor != null)
            {
                try
                {
                    args.NewSensor.DepthStream.Enable(DepthImageFormat.Resolution640x480Fps30);

                    if (args.NewSensor.SkeletonStream.IsEnabled == false)
                    {
                        args.NewSensor.SkeletonStream.Enable(new TransformSmoothParameters() { Correction = 0.5f, JitterRadius = 0.5f, Prediction = 0.5f, Smoothing = 0.9f });

                        args.NewSensor.SkeletonFrameReady += NewSensor_SkeletonFrameReady;
                    }

                    if (args.NewSensor.ColorStream.IsEnabled == false)
                    {
                        args.NewSensor.ColorStream.Enable();

                        args.NewSensor.ColorFrameReady += NewSensor_ColorFrameReady;
                    }

                    //maxScreenHeight = Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenHeight);
                    //maxScreenWidth = Convert.ToInt32(System.Windows.SystemParameters.PrimaryScreenWidth);

                    //maxScreenHeight = Convert.ToInt32(this.KinectCanvas.Height);
                    // maxScreenWidth = Convert.ToInt32(this.KinectCanvas.Width);


                    args.NewSensor.ElevationAngle = 0;

                    try
                    {
                        args.NewSensor.DepthStream.Range = DepthRange.Near;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = true;
                    }
                    catch (InvalidOperationException)
                    {
                        // Non Kinect for Windows devices do not support Near mode, so reset back to default mode.
                        args.NewSensor.DepthStream.Range = DepthRange.Default;
                        args.NewSensor.SkeletonStream.EnableTrackingInNearRange = false;
                    }
                }
                catch (InvalidOperationException)
                {
                    // KinectSensor might enter an invalid state while enabling/disabling streams or stream features.
                    // E.g.: sensor might be abruptly unplugged.
                }
            }
        }
        #endregion


        private void NewSensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        {

        }

        private void NewSensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                //Getting the number of players form the device
                NumberofPlayers = Convert.ToInt16(totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).Count());

                //Getting the first skeleton from the collection
                var firstSkeleton = totalSkeletons.Where(skull => skull.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }


        //private void Sensor_ColorFrameReady(object sender, ColorImageFrameReadyEventArgs e)
        //{

        //}

        //private void Sensor_DepthFrameReady(object sender, DepthImageFrameReadyEventArgs e)
        //{

        //}

        private void Sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (var skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);

                //Getting the number of players form the device
                NumberofPlayers = Convert.ToInt16(totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).Count());

                //Getting the first skeleton from the collection
                var firstSkeleton = totalSkeletons.Where(skull => skull.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }

        private void MapJointsToUIElement(Skeleton firstSkeleton)
        {

            var rightHand = firstSkeleton.Joints[JointType.HandRight];
            var leftHand = firstSkeleton.Joints[JointType.HandLeft];
            var head = firstSkeleton.Joints[JointType.Head];

            var rightElbow = firstSkeleton.Joints[JointType.ElbowRight];
            var leftElbow = firstSkeleton.Joints[JointType.ElbowLeft];

            var HipCenter = firstSkeleton.Joints[JointType.HipCenter];

            //Mapping for right hand
            Point mappedRightHand = rightHand.Position.ScalePosition(this.sensorChooser.Kinect);
            Canvas.SetLeft(this.rightHandPointer, mappedRightHand.X);
            Canvas.SetTop(this.rightHandPointer, mappedRightHand.Y);

            //Mapping for left hand
            Point mappedLeftHand = leftHand.Position.ScalePosition(this.sensorChooser.Kinect); 
            Canvas.SetLeft(this.leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(this.leftHandPointer, mappedLeftHand.Y);

            //Getting the distance between the hands.
            var distanctBetweenHands = Math.Round(leftHand.GetDistance(rightHand));
            //tb_information.Text = distanctBetweenHands.ToString();



            if (leftHand.Position.Y > leftElbow.Position.Y && rightHand.Position.Y > rightElbow.Position.Y)
            {
                if (distanctBetweenHands > 110 && isperformed_fullVolumeGesture == false)
                {
                    PHPCommunicator.DataSender("on", "all", SongURL);
                    isperformed_fullVolumeGesture = true;
                    //MessageBox.Show("arvind");
                }
            }



            else if (leftHand.Position.Y > head.Position.Y)
            {
                if (leftHand.Position.X < head.Position.X && rightHand.Position.Y < rightElbow.Position.Y)
                {
                    //Get the distance and do the programing for implementing the thing. The minimal distance between the 
                    //head and hand is required for implementation. so that precisness would be there.

                    var distanceBetweenLeftHandandHead = Math.Round(head.GetDistance(leftHand));
                    //tb_information.Text = distanceBetweenHandandHead.ToString();

                    if (distanceBetweenLeftHandandHead >= 40 && isPerformed_Device1 == false)
                    {
                        PHPCommunicator.DataSender("on", "1", SongURL);
                        isPerformed_Device1 = true;
                    }
                }
            }

            else if (rightHand.Position.Y > head.Position.Y)
            {
                if (rightHand.Position.X > head.Position.X && leftHand.Position.Y < leftElbow.Position.Y)
                {
                    var distanceBetweenRightHandandHead = Math.Round(head.GetDistance(leftHand));
                    tb_information.Text = distanceBetweenRightHandandHead.ToString();

                    if (distanceBetweenRightHandandHead >= 40 && isPerformed_Device2 == false)
                    {
                        PHPCommunicator.DataSender("on", "2", SongURL);
                        isPerformed_Device2 = true;
                    }
                }
            }

            else if (leftHand.Position.Y > HipCenter.Position.Y && leftHand.Position.X < HipCenter.Position.X && leftHand.Position.Y < leftElbow.Position.Y)
            {
                var distanceBetweenLeftHandandHipCenter = leftHand.GetDistance(HipCenter);
              
                if (distanceBetweenLeftHandandHipCenter > 50 && isPerformed_Device3 == false)
                {
                    isPerformed_Device3 = true;
                    PHPCommunicator.DataSender("on", "3", SongURL);
                }
               
            }

            else if (rightHand.Position.Y > HipCenter.Position.Y && rightHand.Position.X > HipCenter.Position.X && rightHand.Position.Y < rightElbow.Position.Y)
            {
                var distancebetweenRightHandandHipCenter = rightHand.GetDistance(HipCenter);
                if (distancebetweenRightHandandHipCenter > 50 && isPerformed_Device4 == false)
                {
                    isPerformed_Device4 = true;
                    PHPCommunicator.DataSender("on", "4", SongURL);
                }
            }

           
            else if (leftHand.Position.Y < leftElbow.Position.Y &&  rightHand.Position.Y <rightElbow.Position.Y)
            {
                isperformed_fullVolumeGesture = false;
                isPerformed_Device1 = false;
                isPerformed_Device2 = false;
                isPerformed_Device3 = false;
                isPerformed_Device4 = false;

                tb_information.Text = leftHand.GetDistance(firstSkeleton.Joints[JointType.HipCenter]).ToString();
               

                //tb_information.Text = firstSkeleton.Joints[JointType.Head].GetDistance(firstSkeleton.Joints[JointType.FootRight]).ToString() ;
                
            }




           


            //if (firstSkeleton.Joints[JointType.HandLeft].Position.Y < firstSkeleton.Joints[JointType.])
            //{

           // }



            //Gesture Validation and Execution
            //var isHandGesturePerformed = GesturePerformer.MaxHandDistanceGesture(firstSkeleton);

            //if (isHandGesturePerformed == true)
            //{

            //    MessageBox.Show("arvind");
            //    isHandGesturePerformed = false;
            //}


        }

        private void btn_wait_1_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("wait", "1", SongURL);
        }

        private void btn_wait_0_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("wait", "0", SongURL);
        }

        private void btn_on1_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("on", "1", SongURL);
        }

        private void btn_on2_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("on", "2",SongURL);
        }

        private void btn_on3_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("on","3", SongURL);
        }

        private void btn_on4_Click(object sender, RoutedEventArgs e)
        {
            PHPCommunicator.DataSender("on", "4", SongURL);
        }

        //private void btn_vol_plus_HandPointerEnter(object sender, HandPointerEventArgs e)
        //{
        //    //e.HandPointer.GetIsOver(this.btn_vol_plus);

        //    //MessageBox.Show("plus");
           
        //}

        //private void btn_vol_minus_HandPointerEnter(object sender, HandPointerEventArgs e)
        //{
        //    //MessageBox.Show("minus");
           

        //}

        private void Window_Closed(object sender, EventArgs e)
        {
            PHPCommunicator.DataSender("wait", "0", SongURL);
        }

        private void KinectHoverButton_Click(object sender, RoutedEventArgs e)
        {
            if (Volume <= 1.00)
            {
                Volume += 0.01;
                PHPCommunicator.DataSender("volume", Volume.ToString(), VolumeURL);
                btn_vol_increse.Content = Volume * 100;
                btn_vol_desc.Content = Volume * 100;
            }
        }

        private void btn_vol_desc_Click(object sender, RoutedEventArgs e)
        {
            if (Volume >= 0.00)
            {
                Volume -= 0.01;
                PHPCommunicator.DataSender("volume", Volume.ToString(), VolumeURL);
                btn_vol_desc.Content = Volume * 100;
                btn_vol_increse.Content = Volume * 100;

            }
        }
    }
}
