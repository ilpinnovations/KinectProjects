﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Kinect;
using System.Windows;

namespace DeviceComm
{
    public static class Extensions
    {
        public static Point ScalePosition(this SkeletonPoint skeletonPoint, KinectSensor sensor)
        {
            var depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            return new Point() { X = depthImagePoint.X, Y = depthImagePoint.Y };
        }

        public static double GetDistance(this Joint firstJoint, Joint secondJoint)
        {
            var differenceX = firstJoint.Position.X - secondJoint.Position.X;
            var differenceY = firstJoint.Position.Y - secondJoint.Position.Y;
            var differenceZ = firstJoint.Position.Z - secondJoint.Position.Z;

            return Math.Sqrt((differenceX * differenceX) + (differenceY * differenceY) + (differenceZ * differenceZ)) * 100;
        }
    }
}
