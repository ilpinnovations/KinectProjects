﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace ControllingCursorsUsingKinect_WinFormsApp
{
    struct MouseInput
    {
        public int X;
        public int Y;
        public uint MouseData;
        public uint DwFlags;
        public uint Time;
        public IntPtr DwExtraInfo;
    }
    struct Input
    {
        public int Type;
        public MouseInput Data;
    }
    public class MouseSimulator
    {
        [DllImport("user32.dll", SetLastError = true)]
        private static extern uint SendInput (uint nInputs, Input[] pInputs, int cbSize);
        const uint MOUSEEVENTF_LEFTDOWN = 0x02;
        const uint MOUSEEVENTF_LEFTUP = 0x04;
        const uint MOUSEEVENTF_ABSOLUTE = 0x8000;
        const uint MOUSEEVENTF_MOVE = 0x0001;
        const int MOUSEEVENTF_RIGHTDOWN = 0x08;
        const int MOUSEEVENTF_RIGHTUP = 0x10;

        //const uint MOUSEEVENTF_RIGHTDOWN = 0;
        private MouseInput CreateMouseInput(int x, int y, uint data, uint time, uint flag)
        {
            MouseInput Result = new MouseInput();
            Result.X = x;
            Result.Y = y;
            Result.MouseData = data;
            Result.Time = time;
            Result.DwFlags = flag;
            return Result;
        }

        public void SimulateMouseLeftClick()
        {
            Input[] MouseEvent = new Input[2];
            MouseEvent[0].Type = 0;
            MouseEvent[0].Data = CreateMouseInput(0, 0, 0, 0, MOUSEEVENTF_LEFTDOWN);
            MouseEvent[1].Type = 0;
            MouseEvent[1].Data = CreateMouseInput(0, 0, 0, 0, MOUSEEVENTF_LEFTUP);
            SendInput((uint)MouseEvent.Length, MouseEvent, Marshal.SizeOf(MouseEvent[0].GetType()));

        }

        public void SimulateMouseRightClick()
        {
            Input[] MouseEvent = new Input[2];
            MouseEvent[0].Type = 0;
            MouseEvent[0].Data = CreateMouseInput(0, 0, 0, 0, MOUSEEVENTF_RIGHTDOWN);

            MouseEvent[1].Type = 0;
            MouseEvent[1].Data = CreateMouseInput(0, 0, 0, 0, MOUSEEVENTF_RIGHTUP);
            SendInput((uint)MouseEvent.Length, MouseEvent, Marshal.SizeOf(MouseEvent[0].GetType()));

        }

        //Mouse movement controlling using driver
        //public void SimulateMouseMove(int x, int y)
        //{
        //    Input[] MouseEvent = new Input[1];
        //    MouseEvent[0].Type = 0;
        //    MouseEvent[0].Data = CreateMouseInput(x, y, 0, 0, MOUSEEVENTF_ABSOLUTE | MOUSEEVENTF_MOVE);
        //    SendInput((uint)MouseEvent.Length, MouseEvent, Marshal.SizeOf(MouseEvent[0].GetType()));
        //}

    }
}
