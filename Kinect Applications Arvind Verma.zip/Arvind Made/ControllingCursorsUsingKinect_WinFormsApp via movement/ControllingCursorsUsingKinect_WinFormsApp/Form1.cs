﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Coding4Fun.Kinect.WinForm;
using System.Windows;
using WindowsInput;
using Microsoft.Kinect;
using KinectMouseController;

namespace ControllingCursorsUsingKinect_WinFormsApp
{
    public partial class Form1 : Form
    {

        #region KinectSensor and Data Holders
        private KinectSensor sensor;
        private Skeleton[] totalSkeletons = new Skeleton[6];
        private const float SkeletonMaxX = 0.2f;
        private const float SkeletonMaxY = 0.1f;
        short cursorPositionCounter;//if condition statisfy then click fire and reset the timer
        static Point lastPosition;
        static Point currentPosition;
        bool IsLeftClicked;
        bool IsRightClicked;
        bool IsLeftHandUp;
        bool IsRightHandUp;
        MouseSimulator mouse = new MouseSimulator();
        #endregion

        public Form1()
        {
            InitializeComponent();
            try
            {
                sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
                if (sensor == null)
                {
                    return;
                }

                if (sensor.SkeletonStream.IsEnabled == false)
                {
                    #region Standard Smooth Parameters
                    //TransformSmoothParameters parameters = new TransformSmoothParameters();
                    //parameters.Smoothing = 0.7f;
                    //parameters.Correction = 0.3f;
                    //parameters.Prediction = 0.4f;
                    //parameters.JitterRadius = 1.0f;
                    //parameters.MaxDeviationRadius = 0.5f;
                    #endregion

                    TransformSmoothParameters parameters = new TransformSmoothParameters();
                    parameters.Smoothing = 0.9f;
                    parameters.Correction = 0.4f;
                    parameters.Prediction = 0.4f;
                    parameters.JitterRadius = 0.9f;
                    //parameters.MaxDeviationRadius = 0.9f;

                    //Getting data from kinect
                    sensor.SkeletonStream.Enable(parameters);
                    //sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;

                    sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
                    sensor.Start();
                }
                
                sensor.ElevationAngle = 0;
                cursorPositionCounter = 0;
            }
            catch (Exception  exp)
            {
                MessageBox.Show("Kinect Connectivity Issue :"+exp.Message);
            }
        }

        private void clickTimer_Tick(object sender, EventArgs e)
        {
            cursorPositionCounter++;
            if (cursorPositionCounter == 2)
            {
                //tb_timer.Text += "Click Happend"
                //Put the clicking logic here

                if (IsLeftHandUp == true && IsRightHandUp == true && IsRightClicked == false)
                {
                    mouse.SimulateMouseRightClick();
                    IsRightClicked = true;
                    
                }
                else if (IsLeftClicked == false && IsRightHandUp == true)
                {
                    mouse.SimulateMouseLeftClick();
                    IsLeftClicked = true;
                }
                cursorPositionCounter = 0;
                lastPosition = new Point() { X = 0, Y = 0 };
            }
            
        }
        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);
                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }

        private void MapJointsToUIElement(Skeleton skeleton)
        {

            //Joint rightHand = skeleton.Joints[JointType.HandRight];
            //Joint leftHand = skeleton.Joints[JointType.HandLeft];

            Joint scaledRight = skeleton.Joints[JointType.HandRight].ScaleTo(1366, 768, SkeletonMaxX, SkeletonMaxY);
            
            Joint scaledLeft = skeleton.Joints[JointType.HandLeft].ScaleTo(100, 100, SkeletonMaxX, SkeletonMaxY);

            //controlling the cursor using right hand.
            
            if (skeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked && skeleton.Joints[JointType.HandRight].Position.Y > skeleton.Joints[JointType.ElbowRight].Position.Y)
            {
                IsRightHandUp = true;
                IsLeftHandUp = false;


                if (skeleton.Joints[JointType.HandLeft].TrackingState == JointTrackingState.Tracked && skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
                {
                    IsLeftHandUp = true;
                }
                else
                {
                    IsLeftHandUp = false;
                }


                currentPosition = new Point() { X = Convert.ToInt32( scaledRight.Position.X), Y = Convert.ToInt32(scaledRight.Position.Y) };
                Cursor.Position = currentPosition;
                if (lastPosition.X == 0 && lastPosition.Y == 0)
                {
                    lastPosition = currentPosition;
                }
                else if (Math.Abs(Math.Abs(currentPosition.X) - Math.Abs(lastPosition.X)) <= 5)
                {
                    //then start the timer
                    //txt_lastPosition.Text = string.Format("X:{0}, Y:{1}", lastPosition.X, lastPosition.Y);
                    clickTimer.Start();
                    lastPosition = currentPosition;
                }
                else if (Math.Abs(Math.Abs(currentPosition.X) - Math.Abs(lastPosition.X)) > 5)
                {
                    clickTimer.Stop();
                    lastPosition = currentPosition;
                    IsRightClicked = false;
                    IsLeftClicked = false;
                }

               // PerformActions(new Point() { X = Convert.ToInt32(scaledRight.Position.X), Y = Convert.ToInt32( scaledRight.Position.Y) }, new Point() { X =  Convert.ToInt32( scaledLeft.Position.X), Y = Convert.ToInt32( scaledLeft.Position.Y) }, skeleton);
            }
               
            ////controlling the cursor using left hand.
            //else if (skeleton.Joints[JointType.HandLeft].TrackingState == JointTrackingState.Tracked && skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
            //{
            //    IsLeftHandUp = true;
            //    //IsRightHandUp = false;


            //    //currentPosition = new Point() { X = Convert.ToInt32(scaledLeft.Position.X), Y = Convert.ToInt32(scaledLeft.Position.Y) };
            //    //Cursor.Position = currentPosition;
            //    //if (lastPosition.X == 0 && lastPosition.Y == 0)
            //    //{
            //    //    lastPosition = currentPosition;
            //    //}
            //    //else if (Math.Abs(Math.Abs(currentPosition.X) - Math.Abs(lastPosition.X)) <= 5)
            //    //{
            //    //    //then start the timer
            //    //    //txt_lastPosition.Text = string.Format("X:{0}, Y:{1}", lastPosition.X, lastPosition.Y);
            //    //    clickTimer.Start();
            //    //    lastPosition = currentPosition;
            //    //}
            //    //else if (Math.Abs(Math.Abs(currentPosition.X) - Math.Abs(lastPosition.X)) > 5)
            //    //{
            //    //    clickTimer.Stop();
            //    //    lastPosition = currentPosition;
            //    //    IsRightClicked = false;
            //    //    IsLeftClicked = false;
            //    //}


            //    //PerformActions(new Point() { X = Convert.ToInt32( scaledRight.Position.X), Y =  Convert.ToInt32( scaledRight.Position.Y) }, new Point() { X =  Convert.ToInt32( scaledLeft.Position.X), Y = Convert.ToInt32( scaledLeft.Position.Y) }, skeleton);
            //    //Canvas.SetLeft(rightHandPointer, scaledLeft.Position.X);
            //    //Canvas.SetTop(rightHandPointer, scaledLeft.Position.Y);
            //}
            else
            {
                clickTimer.Stop();
                IsRightClicked = false;
                IsLeftClicked = false;
            }

        }

        private void PerformActions(Point mappedHandPoint, Skeleton trackedSkeleton)
        {
            Cursor.Position = mappedHandPoint;
        }


        //this code is no longer required. This is just for reference.
        //private void PerformActions(Point mappedRightHandPoint, Point mappedLeftHandPoint, Skeleton trackedSkeleton)
        //{
        //    #region simulating the mouse co-ordinates using C#

        //    var zHead = (trackedSkeleton.Joints[JointType.Head].Position.Z * 100);
        //    //Implementing the right hand interaction model for right hand pointer.
        //    if (trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.ElbowRight].Position.Y && trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.HandLeft].Position.Y)
        //    {
        //        var zRightHand = (trackedSkeleton.Joints[JointType.HandRight].Position.Z * 100);
        //        Cursor.Position = new Point(mappedRightHandPoint.X, mappedRightHandPoint.Y);

       

        //        var DifferenceBetweenRightHandandHead = zHead - zRightHand;

        //        //tb_difference.Text = DifferenceBetweenRightHandandHead.ToString();

        //        if (DifferenceBetweenRightHandandHead > 45 && IsRightClicked == false)
        //        {

                  
        //            mouse.SimulateMouseRightClick();
        //            IsRightClicked = true;
        //        }
        //        else if (DifferenceBetweenRightHandandHead <= 38 && DifferenceBetweenRightHandandHead > 10)
        //        {
        //            IsRightClicked = false;
        //        }
        //    }


        //    //Implementing the left hand interaction model.
        //    if (trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.ElbowLeft].Position.Y && trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.HandRight].Position.Y)
        //    {
        //        var zLeftHand = (trackedSkeleton.Joints[JointType.HandLeft].Position.Z * 100);

        //        //KinectMouseController.KinectMouseMethods.SendMouseInput(mappedLeftHandPoint.X, mappedLeftHandPoint.Y,

        //        //   1366, 768, false
        //        //   );
        //       // KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, false);
        //       Cursor.Position = new Point(mappedLeftHandPoint.X, mappedLeftHandPoint.Y);
        //        var DifferenceBetweenLeftHandandHead = zHead - zLeftHand;
        //        if (DifferenceBetweenLeftHandandHead > 45 && IsLeftClicked == false)
        //        {
        //           // KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, true);
        //            mouse.SimulateMouseLeftClick();
        //            IsLeftClicked = true;
        //        }
        //        else if (DifferenceBetweenLeftHandandHead <= 38 && DifferenceBetweenLeftHandandHead > 10)
        //        {
        //            IsLeftClicked = false;
        //        }
        //    }

        //    #endregion

        //    //Not able to handle the events.
        //    //Cursor.Position = new Point(mappedRightHandPoint.X, mappedRightHandPoint.Y);//Implementing the cursor using winforms managed api.

        //    //mouse.SimulateMouseClick();

        //    //Driver Approach
        //    //mouse.SimulateMouseMove(mappedRightHandPoint.X, mappedRightHandPoint.Y);
        //}

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            //stopping the sensor.
            if (sensor != null)
            {
                sensor.Stop();                
            }
        }

        private void btn_control1_Click(object sender, EventArgs e)
        {
            label1.Text = "Control 1 is clicked using Kinect Cursor !";
        }

        private void btn_control2_Click(object sender, EventArgs e)
        {
            label1.Text = "Control 2 is clicked using Kinect Cursor !";
        }

        private void btn_stopTracking_Click(object sender, EventArgs e)
        {
            if (sensor != null && sensor.SkeletonStream.IsEnabled == true && btn_stopTracking.Text == "Stop Tracking")
            {
                sensor.SkeletonStream.Disable();
                btn_stopTracking.Text = "Start Tracking";
            }
            else if (sensor !=null && sensor.SkeletonStream.IsEnabled == false && btn_stopTracking.Text =="Start Tracking")
            {
                sensor.SkeletonStream.Enable();
                btn_stopTracking.Text = "Stop Tracking";
            }
        }

        //Mapping the co-ordinate with scaling. No Physical Interaction Zone Mapping
        //private Point ScalePosition(SkeletonPoint skeletonPoint)
        //{
        //    DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
        //    //return PointToScreen(new Point(depthImagePoint.X, depthImagePoint.Y));
        //    return new Point((depthImagePoint.X), (depthImagePoint.Y));
        //}

       
    }
}
