﻿using System.Windows;
using Microsoft.Kinect;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System;

namespace HandTrackingUsingKinect
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {


        private KinectSensor sensor;
        Skeleton[] totalSkelton = new Skeleton[6]; //Number of skeleton can be tracked = 6.

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
            if (sensor.SkeletonStream.IsEnabled == false)
            {
                //sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;
                sensor.SkeletonStream.Enable();
                sensor.SkeletonFrameReady += new System.EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
            }
            sensor.Start();
        }

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }
                skeletonFrame.CopySkeletonDataTo(totalSkelton);

                Skeleton firstOne = (from trackedSkelton in totalSkelton
                                     where trackedSkelton.TrackingState == SkeletonTrackingState.Tracked
                                     select trackedSkelton).FirstOrDefault();

                if (firstOne == null)
                {
                    return;
                }

                if (firstOne.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsWithUIElement(firstOne);
                }

                if (firstOne.Joints[JointType.HandLeft].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsWithUIElement(firstOne);
                }

            }
        }

        private void MapJointsWithUIElement(Skeleton skeleton)
        {
            //Mapping of right hand on the canvas using stackpanel.
            Point mappedRightPoint = this.ScalePosition(skeleton.Joints[JointType.HandRight].Position, true);
            Canvas.SetLeft(this.stackPanel_Right, mappedRightPoint.X);
            Canvas.SetTop(this.stackPanel_Right, mappedRightPoint.Y);
            tb_RightHand.Text = string.Format("X:{0},Y:{1}", mappedRightPoint.X, mappedRightPoint.Y);


            Point mappedLeftPoint = this.ScalePosition(skeleton.Joints[JointType.HandLeft].Position, false);
            Canvas.SetLeft(this.stackPanel_Left, mappedLeftPoint.X);
            Canvas.SetTop(this.stackPanel_Left, mappedLeftPoint.Y);
            tb_LeftHand.Text = string.Format("X:{0},Y:{1}", mappedLeftPoint.X, mappedLeftPoint.Y);

            //Applying Logic to the data.
            //if (skeleton.Joints[JointType.HandLeft].Position.Y < skeleton.Joints[JointType.HandRight].Position.Y)
            //{
            //    //Color c = new Color ();
            //    //c.A = 100;
            //    //c.B= 100;
            //    //c.G = 0;
            //    //c.R = 100;
            //    //this.RightHand.Fill = new SolidColorBrush(c);

            //    //Canvas.SetLeft(this.rec_ActiveRegionRight, mappedRightPoint.X);
            //    //Canvas.SetTop(this.rec_ActiveRegionRight, mappedRightPoint.Y);

            //}


            //Processing the Z - Co ordinate of application.

            var leftHandZ = skeleton.Joints[JointType.HandLeft].Position.Z;
            var rightHandZ = skeleton.Joints[JointType.HandRight].Position.Z;

            this.tb_leftHand_Z.Text = "LEFT HAND Z CO-ORDINATE " + Convert.ToString(leftHandZ) + "   ";
            this.tb_rightHand_Z.Text = "RIGHT HAND Z CO-ORDINATE  " + Convert.ToString(rightHandZ) + "   ";


            //Applying the logic using z co-ordinate.
            #region Applying the gesture recognition condition. (Relative Position Hand Gesture.)
            //if (leftHandZ - rightHandZ > 0.2)
            //{

            //    Canvas.SetLeft(this.rec_ActiveRegionRight, mappedRightPoint.X);
            //    Canvas.SetTop(this.rec_ActiveRegionRight, mappedRightPoint.Y);
            //    this.rec_ActiveRegionRight.Fill = new SolidColorBrush(new Color() { A = 100, B = 100, R = 100, G = 0 });

            //}
            //else
            //{
            //    this.rec_ActiveRegionRight.Fill = new SolidColorBrush(new Color() { A = 50, B = 45, R = 100, G = 0 });
            //}
            #endregion




            //Doing it more precisely.

            
       #region Relative Hand Gesture Recognition.
            //condition for default traking mode.
            //skeleton.Joints[JointType.Spine].Position.Z > skeleton.Joints[JointType.HandRight].Position.Z  && skeleton.Joints[JointType.Head].Position.Z > skeleton.Joints[JointType.HandRight].Position.Z(not gonna work as expected.)



            //Condition for seated tracking mode.
            if (skeleton.Joints[JointType.Head].Position.Z > skeleton.Joints[JointType.HandRight].Position.Z && skeleton.Joints[JointType.ElbowRight].Position.Y < skeleton.Joints[JointType.HandRight].Position.Y)
            {
                //Gesture Recognized.
                //Controlling the right hand gesture.
                Canvas.SetLeft(this.rec_ActiveRegionRight, mappedRightPoint.X);
                Canvas.SetTop(this.rec_ActiveRegionRight, mappedRightPoint.Y);
                this.rec_ActiveRegionRight.Fill = new SolidColorBrush(new Color() { A = 100, B = 45, R = 100, G = 0 });
                

            }


            if (skeleton.Joints[JointType.Head].Position.Z > skeleton.Joints[JointType.HandLeft].Position.Z && skeleton.Joints[JointType.ElbowLeft].Position.Y < skeleton.Joints[JointType.HandLeft].Position.Y)
            {
                //Gesture Recognized.
                //Controlling left hand gesture.
                Canvas.SetLeft(this.rec_ActiveRegionLeft, mappedLeftPoint.X);
                Canvas.SetTop(this.rec_ActiveRegionLeft, mappedLeftPoint.Y);
                this.rec_ActiveRegionLeft.Fill = new SolidColorBrush(new Color() { A = 100, B = 45, R = 100, G = 0 });
                



                //sample code - testing v1.0

               


            }


            


            #endregion





            //trying another condition.
            //custom gesture.
            #region When left hand is over your head, then you can move the rectangle using your right hand.
            //if (skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.Head].Position.Y)
            //{
            //    //under hand control.
            //    Canvas.SetLeft(this.rec_ActiveRegionRight, mappedRightPoint.X);
            //    Canvas.SetTop(this.rec_ActiveRegionRight, mappedRightPoint.Y);
            //    this.rec_ActiveRegionRight.Fill = new SolidColorBrush(new Color() { A = 100, B = 100, R = 100, G = 0 });
            //}

            //else
            //{
            //    //do something.
            //    //No controlling with hand but updated position.
            //    this.rec_ActiveRegionRight.Fill = new SolidColorBrush(new Color() { A = 50, B = 45, R = 100, G = 0 });
            //}
            #endregion

        }

        private Point ScalePosition(SkeletonPoint skeletonPoint, bool RightOrLeft)
        {
            DepthImagePoint depthPoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint,
                DepthImageFormat.Resolution640x480Fps30);

            if (RightOrLeft)
            {
                sb_info.Items.Clear();
                sb_info.Items.Add("Depth (Right Hand)" + depthPoint.Depth);
            }

            return new Point(depthPoint.X, depthPoint.Y);
        }

        
    }
}
