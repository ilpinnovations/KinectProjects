﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using Microsoft.Kinect;
using System.Windows.Shapes;
using Microsoft.Speech.Recognition;

namespace SoundDetector
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        #region KinectObjects
        KinectSensor sensor;
        #endregion

       

        public MainWindow()
        {
            InitializeComponent();
            

            sensor = KinectSensor.KinectSensors.Where(sense=> sense.Status == KinectStatus.Connected).FirstOrDefault();
            if (sensor== null)
            {
                return;
            }
            sensor.Start();

            if (sensor.AudioSource != null)
            {
                 sensor.AudioSource.BeamAngleMode = BeamAngleMode.Automatic;
                 sensor.AudioSource.BeamAngleChanged += AudioSource_BeamAngleChanged;
                 sensor.AudioSource.SoundSourceAngleChanged += AudioSource_SoundSourceAngleChanged;
                 sensor.AudioSource.Start();
                
            }
        }

        void jarvis_RecognizeCompleted(object sender, RecognizeCompletedEventArgs e)
        {
            tb_soundBeamAngle.Text = e.Result.Text;
        }

        void AudioSource_SoundSourceAngleChanged(object sender, SoundSourceAngleChangedEventArgs e)
        {
            tb_soundSourceAngle.Text = "Sound Source Angle :" + e.Angle.ToString() + " ConfidenceLevel :" + e.ConfidenceLevel; 
        }

        void AudioSource_BeamAngleChanged(object sender, BeamAngleChangedEventArgs e)
        {
            tb_soundBeamAngle.Text = "Sound Beam Angle :" + e.Angle.ToString();
        }


    }
}
