﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Shapes;
using System.Windows;
using System.Windows.Media;

namespace CustomCursor
{
    public static class RectangleExtension
    {
        public static CustomCursor.RectanglePosition GetPosition(this Rectangle rectangle)
        {

            Point rectanglePosition = rectangle.PointToScreen(new Point());
            return new CustomCursor.RectanglePosition() { 
            Left = rectanglePosition.X,
            Right = rectanglePosition.X + rectangle.ActualWidth,
            Top = rectanglePosition.Y,
            Bottom = rectanglePosition.Y + rectangle.ActualHeight
            };
        }
    }
}
