﻿using System;
using System.Linq;
using System.Windows;
using Microsoft.Kinect;
using System.Windows.Controls;
using System.Windows.Media;
using Coding4Fun.Kinect.Wpf;
using KinectMouseController;
using System.Windows.Forms;



namespace CustomCursor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        #region KinectSensor and Data Holders
        private KinectSensor sensor;
        private Skeleton[] totalSkeletons = new Skeleton[6];
        private const float SkeletonMaxX = 0.60f;
        private const float SkeletonMaxY = 0.40f;
        bool IsLeftClicked;
        bool IsRightClicked;
        #endregion

        public MainWindow()
        {
            InitializeComponent();
            sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
            if (sensor.SkeletonStream.IsEnabled == false)
            {
                //Getting data from kinect
                sensor.SkeletonStream.Enable();
                //sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;

                sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
            }
            sensor.Start();
            sensor.ElevationAngle = 0;

        }

        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);
                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }


        private void PerformActions(Point mappedRightHandPoint, Point mappedLeftHandPoint, Skeleton trackedSkeleton)
        {
            var zHead = (trackedSkeleton.Joints[JointType.Head].Position.Z * 100);
            //Implementing the right hand interaction model for right hand pointer.
            if (trackedSkeleton.Joints[JointType.HandRight].Position.Y > trackedSkeleton.Joints[JointType.WristRight].Position.Y)
            {
                var zRightHand = (trackedSkeleton.Joints[JointType.HandRight].Position.Z * 100);

                KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedRightHandPoint.X), Convert.ToInt32(mappedRightHandPoint.Y), (int)System.Windows.SystemParameters.PrimaryScreenWidth, (int)System.Windows.SystemParameters.PrimaryScreenHeight, false);

                var DifferenceBetweenRightHandandHead = zHead - zRightHand;

                //tb_difference.Text = DifferenceBetweenRightHandandHead.ToString();

                if (DifferenceBetweenRightHandandHead > 45 && IsRightClicked == false)
                {
                    KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedRightHandPoint.X), Convert.ToInt32(mappedRightHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, true);

                    IsRightClicked = true;
                }
                else if (DifferenceBetweenRightHandandHead <= 38 && DifferenceBetweenRightHandandHead > 10)
                {
                    IsRightClicked = false;
                }
            }
            //Implementing the left hand interaction model for left hand model.
            if (trackedSkeleton.Joints[JointType.HandLeft].Position.Y > trackedSkeleton.Joints[JointType.WristLeft].Position.Y)
            {
                var zLeftHand = (trackedSkeleton.Joints[JointType.HandLeft].Position.Z * 100);
                KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, false);
                var DifferenceBetweenLeftHandandHead = zHead - zLeftHand;
                if (DifferenceBetweenLeftHandandHead > 45 && IsLeftClicked == false)
                {
                    KinectMouseMethods.SendMouseInput(Convert.ToInt32(mappedLeftHandPoint.X), Convert.ToInt32(mappedLeftHandPoint.Y), (int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, true);
                    IsLeftClicked = true;
                }
                else if (DifferenceBetweenLeftHandandHead <= 38 && DifferenceBetweenLeftHandandHead > 10)
                {
                    IsLeftClicked = false;
                }
            }
        }

        private void MapJointsToUIElement(Skeleton skeleton)
        {

            Joint rightHand = skeleton.Joints[JointType.HandRight];
            Joint leftHand = skeleton.Joints[JointType.HandLeft];

            Joint scaledRight = rightHand.ScaleTo((int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, SkeletonMaxX, SkeletonMaxY);
            Joint scaledLeft = leftHand.ScaleTo((int)SystemParameters.PrimaryScreenWidth, (int)SystemParameters.PrimaryScreenHeight, SkeletonMaxX, SkeletonMaxY);



            //controlling the cursor using right hand.
            if (skeleton.Joints[JointType.HandRight].Position.Y > skeleton.Joints[JointType.ElbowRight].Position.Y)
            {

                PerformActions(new Point() { X = scaledRight.Position.X, Y = scaledRight.Position.Y }, new Point() { X = scaledLeft.Position.X, Y = scaledLeft.Position.Y }, skeleton);


                //Canvas.SetLeft(rightHandPointer, scaledRight.Position.X);
                //Canvas.SetTop(rightHandPointer, scaledRight.Position.Y);

                //implement the mouse controller code here.



                //KinectMouseMethods.SendMouseInput(Convert.ToInt32(scaledRight.Position.X), Convert.ToInt32(scaledRight.Position.Y), (int)SystemParameters.PrimaryScreenWidth, (int) SystemParameters.PrimaryScreenHeight, false);    


            }

            //controlling the cursor using left hand.
            if (skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
            {
                PerformActions(new Point() { X = scaledRight.Position.X, Y = scaledRight.Position.Y }, new Point() { X = scaledLeft.Position.X, Y = scaledLeft.Position.Y }, skeleton);
                //Canvas.SetLeft(rightHandPointer, scaledLeft.Position.X);
                //Canvas.SetTop(rightHandPointer, scaledLeft.Position.Y);
            }



            //Point mappedRightHand = ScalePosition(skeleton.Joints[JointType.HandRight].Position);
            //tb_X.Text = mappedRightHand.X.ToString();
            //tb_Y.Text = mappedRightHand.Y.ToString();
            //Canvas.SetLeft(rightHandPointer, mappedRightHand.X);
            //Canvas.SetTop(rightHandPointer, mappedRightHand.Y);

            //Point mappedLeftHand = ScalePosition(skeleton.Joints[JointType.HandLeft].Position);
            //Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            //Canvas.SetLeft(leftHandPointer, mappedLeftHand.Y);




            //Point rec_Coordinate = this.rec_ActiveRegion.PointToScreen(new Point() { X = 0, Y = 0 });
            //tb_recLeft.Text = rec_Coordinate.X.ToString();
            //tb_recRight.Text = rec_Coordinate.Y.ToString();



            //CustomCursor.RectanglePosition rectangleRange = CustomCursor.RectangleExtension.GetPosition(this.rec_ActiveRegion);
            //tb_recLeft.Text = rectangleRange.Left.ToString();
            //tb_recRight.Text = rectangleRange.Right.ToString();
            //tb_recTop.Text = rectangleRange.Top.ToString();
            //tb_recBottom.Text = rectangleRange.Bottom.ToString();

            //Point cursorPoint = this.PointToScreen(mappedRightHand);

            //if ((cursorPoint.X < rectangleRange.Left || cursorPoint.X > rectangleRange.Right) || (cursorPoint.Y < rectangleRange.Top || cursorPoint.Y > rectangleRange.Bottom))
            //{
            //    this.tb_information.Text = "hand cursor not in rectangle position";
            //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("InactiveRegionColor");
            //}
            //else
            //{
            //    tb_information.Text = "within limits.";

            //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("ActiveRegionColor");



            //    if (skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
            //    {
            //        //the move the block.
            //        Canvas.SetLeft(this.rec_ActiveRegion, (mappedRightHand.X - rec_ActiveRegion.ActualWidth / 2));
            //        Canvas.SetTop(this.rec_ActiveRegion, (mappedRightHand.Y - rec_ActiveRegion.ActualHeight / 2));
            //    }
            //}


        }

        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            //return PointToScreen(new Point(depthImagePoint.X, depthImagePoint.Y));
            return new Point((depthImagePoint.X), (depthImagePoint.Y));

        }

        private void Window_Closed(object sender, EventArgs e)
        {
            //sensor should stop.
            sensor.Stop();
        }

        //Getting the current position of the cursor.
        //public CustomCursor.CursorPoint GetCursorPoint()
        //{
        //    Point elementTopLeft = this.PointToScreen(new Point() { X = 0, Y = 0 });
        //    double centerX = elementTopLeft.X + (this.ActualWidth / 2);
        //    double centerY = elementTopLeft.Y + (this.ActualHeight / 2);
        //    return new CursorPoint() { X = centerX, Y = centerY };
        //}
    }
}
