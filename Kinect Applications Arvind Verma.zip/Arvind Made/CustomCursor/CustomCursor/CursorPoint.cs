﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CustomCursor
{
    public class CursorPoint
    {
        public double X { get; set; }
        public double Y { get; set; }
    }
}
