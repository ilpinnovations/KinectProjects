﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Shapes;

namespace CustomCursor
{
    public class UIElementCollection
    {
         List<UIElement> Rectangles = new List<UIElement>();


        public UIElementCollection(UIElement[] rectangles)
        {
            foreach (var item in rectangles)
            {
                Rectangles.Add(item);
            }
        }

        public UIElement GetUIElementToControl(Point cursorPointRight, Point cursorPointLeft)
        {
            UIElement SelectedGeometry= null;
            foreach (UIElement item in Rectangles)
            {
              CustomCursor.RectanglePosition rectangleRange = CustomCursor.RectangleExtension.GetPosition((Rectangle)item);

              if ((cursorPointRight.X < rectangleRange.Left || cursorPointRight.X > rectangleRange.Right) || (cursorPointRight.Y < rectangleRange.Top || cursorPointRight.Y > rectangleRange.Bottom))
              {
                  //this.tb_information.Text = "hand cursor not in rectangle position";
                  //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("InactiveRegionColor");

                  //not in range.
              }
              else
              {
                  if ((cursorPointLeft.X < rectangleRange.Left || cursorPointLeft.X > rectangleRange.Right) || (cursorPointLeft.Y < rectangleRange.Top || cursorPointLeft.Y > rectangleRange.Bottom))
                  {
                      //this.tb_information.Text = "hand cursor not in rectangle position";
                      //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("InactiveRegionColor");

                      // not in range
                  }
                  else
                  {
                      SelectedGeometry = item;  
                  }
              }

              
            }
            return SelectedGeometry;
        }
    }
}
