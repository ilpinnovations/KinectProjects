﻿using System;
using System.Windows;
using System.Linq;
using Microsoft.Kinect;
using System.Windows.Controls;
using System.Windows.Media;

namespace CustomCursor
{
    /// <summary>
    /// Interaction logic for BlockLifting.xaml
    /// </summary>
    public partial class BlockLifting : Window
    {

        #region KinectSensor and Data Holders
        private KinectSensor sensor;
        private Skeleton[] totalSkeletons = new Skeleton[6];
        #endregion

        public BlockLifting()
        {
            InitializeComponent();
            sensor = KinectSensor.KinectSensors.Where(sense => sense.Status == KinectStatus.Connected).FirstOrDefault();
            if (sensor.SkeletonStream.IsEnabled == false)
            {
                //Getting data from kinect
                sensor.SkeletonStream.Enable();
                //sensor.SkeletonStream.TrackingMode = SkeletonTrackingMode.Seated;

                sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
            }
            sensor.Start();
            sensor.ElevationAngle = 0;
        }


        void sensor_SkeletonFrameReady(object sender, SkeletonFrameReadyEventArgs e)
        {
            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame == null)
                {
                    return;
                }

                skeletonFrame.CopySkeletonDataTo(totalSkeletons);
                var firstSkeleton = totalSkeletons.Where(skeleton => skeleton.TrackingState == SkeletonTrackingState.Tracked).FirstOrDefault();

                if (firstSkeleton == null)
                {
                    return;
                }

                if (firstSkeleton.Joints[JointType.HandRight].TrackingState == JointTrackingState.Tracked)
                {
                    MapJointsToUIElement(firstSkeleton);
                }
            }
        }


        private void MapJointsToUIElement(Skeleton skeleton)
        {

            

            Point mappedRightHand = ScalePosition(skeleton.Joints[JointType.HandRight].Position);
            Canvas.SetLeft(rightHandPointer, mappedRightHand.X);
            Canvas.SetTop(rightHandPointer, mappedRightHand.Y);

            Point mappedLeftHand = ScalePosition(skeleton.Joints[JointType.HandLeft].Position);
            Canvas.SetLeft(leftHandPointer, mappedLeftHand.X);
            Canvas.SetTop(leftHandPointer, mappedLeftHand.Y);

            //Point rec_Coordinate = this.rec_ActiveRegion.PointToScreen(new Point() { X = 0, Y = 0 });
            //tb_recLeft.Text = rec_Coordinate.X.ToString();
            //tb_recRight.Text = rec_Coordinate.Y.ToString();


            //UIElement ActiveBlock;
            //foreach (UIElement item in KinectCanvas.Children)
            //{
            //    if ((Panel.GetZIndex(this.rightHandPointer) - Panel.GetZIndex(item)) == 1)
            //    {
            //        ActiveBlock = item;
            //        return;
            //    }
            //}



            CustomCursor.RectanglePosition rectangleRange = CustomCursor.RectangleExtension.GetPosition(this.rec_ActiveRegion1);

            tb_recLeft.Text = rectangleRange.Left.ToString();
            tb_recRight.Text = rectangleRange.Right.ToString();
            tb_recTop.Text = rectangleRange.Top.ToString();
            tb_recBottom.Text = rectangleRange.Bottom.ToString();


            Point cursorPointRight = this.PointToScreen(mappedRightHand);
            Point cursorPointLeft = this.PointToScreen(mappedLeftHand);//parameters gonna be passed.

            tb_leftHandX.Text = cursorPointLeft.X.ToString();
            tb_leftHandY.Text = cursorPointLeft.Y.ToString();

            tb_rightHandX.Text = cursorPointRight.X.ToString();
            tb_rightHandY.Text = cursorPointRight.Y.ToString();


            if ((cursorPointRight.X < rectangleRange.Left || cursorPointRight.X > rectangleRange.Right) || (cursorPointRight.Y < rectangleRange.Top || cursorPointRight.Y > rectangleRange.Bottom))
            {
                //this.tb_information.Text = "hand cursor not in rectangle position";
                //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("InactiveRegionColor");

                //not in range.
            }
            else
            {
                if ((cursorPointLeft.X < rectangleRange.Left || cursorPointLeft.X > rectangleRange.Right) || (cursorPointLeft.Y < rectangleRange.Top || cursorPointLeft.Y > rectangleRange.Bottom))
                {
                    //this.tb_information.Text = "hand cursor not in rectangle position";
                    //    rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("InactiveRegionColor");

                    // not in range
                }
                else
                {
                    #region center of virtual line
                    var centerX = Convert.ToInt32((cursorPointRight.X + cursorPointLeft.X) / 2);
                    var centerY = Convert.ToInt32((cursorPointLeft.Y + cursorPointRight.Y) / 2);
                    #endregion


                    var distance = Math.Abs(Convert.ToInt32(GetDistance(skeleton.Joints[JointType.HandLeft], skeleton.Joints[JointType.HandRight]) * 100));

                    tb_distance.Text = distance.ToString();

                    if (distance < 45 && distance > 20)
                    {
                        Canvas.SetLeft(this.rec_ActiveRegion1, (centerX - rec_ActiveRegion1.ActualWidth / 2));
                        Canvas.SetTop(this.rec_ActiveRegion1, (centerY - rec_ActiveRegion1.ActualHeight / 2));
                    }


                    //tb_information.Text = "within limits.";

                    //  rec_ActiveRegion.Fill = (Brush)Application.Current.MainWindow.FindResource("ActiveRegionColor");

                    //if (skeleton.Joints[JointType.HandLeft].Position.Y > skeleton.Joints[JointType.ElbowLeft].Position.Y)
                    //{
                    //    //the move the block.
                    //    //         Canvas.SetLeft(this.rec_ActiveRegion, (mappedRightHand.X - rec_ActiveRegion.ActualWidth / 2));
                    //    //           Canvas.SetTop(this.rec_ActiveRegion, (mappedRightHand.Y - rec_ActiveRegion.ActualHeight / 2));
                    //}
                }


            }
        }


        private float GetDistance(Joint firstJoint, Joint secondJoint)
        {
            float distanceX = firstJoint.Position.X - secondJoint.Position.X;
            float distanceY = firstJoint.Position.Y - secondJoint.Position.Y;
            float distanceZ = firstJoint.Position.Z - secondJoint.Position.Z;
            return (float)Math.Sqrt(Math.Pow(distanceX, 2) + Math.Pow(distanceY, 2) + Math.Pow(distanceZ, 2));
        }


        private Point ScalePosition(SkeletonPoint skeletonPoint)
        {
            DepthImagePoint depthImagePoint = sensor.CoordinateMapper.MapSkeletonPointToDepthPoint(skeletonPoint, DepthImageFormat.Resolution640x480Fps30);
            //return PointToScreen(new Point(depthImagePoint.X, depthImagePoint.Y));
            return new Point(depthImagePoint.X, depthImagePoint.Y);
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            sensor.Stop();
        }
    }
}
